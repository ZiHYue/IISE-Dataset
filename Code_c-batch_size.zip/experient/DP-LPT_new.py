#!/usr/bin/env python
# coding=utf-8

import numpy as np
import time
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple


@dataclass
class Batch:
    jobs: List[int]          # 作业下标（0-based）
    p: float                 # 批处理时间


def batch_processing_time(job_size: np.ndarray, jobs: List[int], S: float) -> float:
    """p(B) = max{s_j} * (1 + sum{s_j}/S)"""
    sizes = job_size[jobs]
    return float(np.max(sizes) * (1.0 + np.sum(sizes) / S))


def dp_single_machine_batches(job_size: np.ndarray, S: float) -> Tuple[np.ndarray, List[List[int]], np.ndarray]:
    """
    单机DP：
    输出 sigma, B(批列表), p(每批处理时间)
    job_size 已经是非递减排序
    """
    n = len(job_size)
    f = np.zeros(n + 1)
    sigma = np.zeros(n + 1, dtype=int)

    # 初始化边界条件
    f[n] = 0.0      #边界条件：没有作业时处理时间为0
    sigma[n] = n    #边界条件：没有作业时结束位置为n

    # 预计算累积和数组以优化求和操作
    cumulative_sum = np.zeros(n + 1)
    cumulative_sum[1:] = np.cumsum(job_size)

    # 反向动态规划，从 k=n-1 到 k=0 反向计算
    for k in range(n - 1, -1, -1):
        si = k + 1
        fi = sigma[k + 1]

        # 处理边界情况
        if si > fi:
            f[k] = 0.0
            sigma[k] = si
            continue

        # 预计算每个可能区间的max_sj
        max_sj_values = np.maximum.accumulate(job_size[si - 1:fi])

        # 计算每个可能区间的fit值
        fit_values = np.zeros(fi - si + 1)
        for idx in range(fi - si + 1):
            current_i = si + idx
            max_sj = max_sj_values[idx]
            sum_si = cumulative_sum[current_i] - cumulative_sum[si - 1]
            batch_time = max_sj * (1.0 + sum_si / S)
            fit_values[idx] = batch_time + f[current_i]

        # 找到最小值和对应的索引
        min_idx = int(np.argmin(fit_values))
        f[k] = float(fit_values[min_idx])
        sigma[k] = si + min_idx

    # 回溯构造批
    B: List[List[int]] = []
    j = 0
    while j < n:
        bs = int(sigma[j])
        B.append(list(range(j, bs)))
        j = bs

    bn = len(B)
    p = np.zeros(bn)
    for b in range(bn):
        p[b] = batch_processing_time(job_size, B[b], S)

    Cmax_DP = np.sum(p)

    return sigma, B, p, Cmax_DP

def lpt_assign_batches(B, p, m):
    """
    按 LPT 规则将批次分配到 m 台机器：
    1) 批次按加工时间 p 非递增排序
    2) 依次分配到当前负载最小的机器
    返回：Cmax_multi, loads, assignment
      - loads[i]: 第 i 台机器总负载
      - assignment[i]: [(batch_id, p_time, jobs_in_batch), ...]
    """
    bn = len(B)
    order = sorted(range(bn), key=lambda b: p[b], reverse=True)

    loads = [0.0] * m
    assignment = [[] for _ in range(m)]

    for b in order:
        i = min(range(m), key=lambda t: loads[t])  # 当前负载最小
        loads[i] += float(p[b])
        assignment[i].append((b, float(p[b]), B[b]))

    Cmax_multi = max(loads) if loads else 0.0
    return Cmax_multi, loads, assignment






if __name__ == "__main__":
    # np.random.seed(42)
    # n = 10000
    # m = 20
    # S = 10.0
    #
    # # 直接生成(0, 10]之间的均匀分布，排除0
    # job_size = np.random.uniform(low=1e-10, high=10.0, size=n)
    # # 使用astype进行内存优化
    # job_size = np.round(job_size, 3).astype(np.float32)


    # 2. LPT 小品种大批量
    type_data = [
        (5, 2594),
        (10, 3952),
        (15, 2332),
        (20, 4319),
        (25, 2389),
    ]
    #
    # 1) 展开成作业列表：每个Ni重复numi次
    Ni_vals = np.array([x for x, c in type_data], dtype=np.float32)
    numi_vals = np.array([c for x, c in type_data], dtype=np.int32)

    job_size = np.repeat(Ni_vals, numi_vals).astype(np.float32)

    job_size = np.sort(job_size)
    n = len(job_size)
    m = 4
    S = 30


    start_time = time.time()
    sigma, B, p, Cmax_single = dp_single_machine_batches(job_size, S)
    Cmax_multi, loads, assignment = lpt_assign_batches(B, p, m)
    end_time =  time.time()
    LowerBound = Cmax_single/m

    print()
    print("=== DP-LPT ===")
    print("Cmax_single:", Cmax_single)
    print("Cmax_multi:", Cmax_multi)
    print(f"运行时间: {end_time - start_time:.6f} 秒")
    print()



# #1. LS 多品种小批量
    # type_data = [
    #     (0.34, 301),
    #     (0.66, 431),
    #     (2.46, 476),
    #     (2.93, 373),
    #     (5.83, 435),
    #     (6.72, 485),
    #     (7.41, 366),
    #     (8.87, 380),
    #     (11.88, 395),
    #     (12.61, 343),
    #     (14.69, 470),
    #     (15.91, 300),
    #     (16.49, 350),
    #     (16.87, 497),
    #     (18.70, 458),
    #     (20.71, 396),
    #     (20.98, 399),
    #     (21.04, 454),
    #     (21.59, 482),
    #     (22.23, 474),
    #     (23.58, 352),
    #     (23.76, 328),
    #     (24.21, 354),
    #     (24.27, 309),
    #     (24.31, 328),
    #     (24.43, 484),
    #     (24.44, 441),
    #     (24.49, 391),
    #     (24.55, 482),
    #     (24.63, 361),
    #     (24.65, 433),
    #     (24.71, 317),
    #     (24.77, 370),
    #     (24.82, 339),
    #     (24.93, 304),
    #     (24.95, 315),
    #     (24.96, 335),
    #     (24.97, 435),
    #     (24.99, 373),
    #     (25.00, 346),
    # ]

    # # 2. LPT 小品种大批量
    # type_data = [
    #     (5, 2594),
    #     (10, 3952),
    #     (15, 2332),
    #     (20, 4319),
    #     (25, 2389),
    # ]
    #
    # # 1) 展开成作业列表：每个Ni重复numi次
    # Ni_vals = np.array([x for x, c in type_data], dtype=np.float32)
    # numi_vals = np.array([c for x, c in type_data], dtype=np.int32)
    #
    # job_size = np.repeat(Ni_vals, numi_vals).astype(np.float32)
    #
    # job_size = np.sort(job_size)
    # n = len(job_size)
    # m = 4
    # S = 30