import numpy as np
import time
from typing import List, Tuple, Dict, Any



def batch_p(job_size: np.ndarray, jobs_asc: List[int], S: float) -> float:
    """
    批处理时间：p(B) = max(s) * (1 + sum(s)/S)
    现在 jobs_asc 按 size 非递减（小->大），所以 max(s) = sizes[-1]
    """
    sizes = job_size[jobs_asc]
    return float(sizes[-1] * (1.0 + float(np.sum(sizes)) / S))


def dp_single_machine_batches(job_size_sorted: np.ndarray, S: float) -> Tuple[np.ndarray, List[List[int]], np.ndarray]:
    """
    DP（单机最优组批）
    注意：job_size 由外部保证已经 SPT 非递减排序
    输出：sigma, B(连续段批，批内按索引升序/size非递减), p(每批处理时间)
    """
    job_size = job_size_sorted
    n = len(job_size)

    f = np.zeros(n + 1)
    sigma = np.zeros(n + 1, dtype=int)
    f[n] = 0.0
    sigma[n] = n

    prefix = np.zeros(n + 1)
    prefix[1:] = np.cumsum(job_size)

    for k in range(n - 1, -1, -1):
        si = k + 1
        fi = sigma[k + 1]

        if si > fi:
            f[k] = 0.0
            sigma[k] = si
            continue

        max_vals = np.maximum.accumulate(job_size[si - 1:fi])
        fit = np.zeros(fi - si + 1)

        for idx in range(fi - si + 1):
            cur_i = si + idx
            max_s = max_vals[idx]  # = max(job_size[k:cur_i])
            sum_s = prefix[cur_i] - prefix[si - 1]
            p_batch = max_s * (1.0 + sum_s / S)
            fit[idx] = p_batch + f[cur_i]

        best = int(np.argmin(fit))
        f[k] = float(fit[best])
        sigma[k] = si + best

    # 回溯批（连续段，批内升序）
    B = []
    j = 0
    while j < n:
        bs = int(sigma[j])
        B.append(list(range(j, bs)))
        j = bs

    p = np.array([batch_p(job_size, b, S) for b in B], dtype=float)
    return sigma, B, p


class SegmentHelper:
    """
    SegmentHelper：对 jobs_asc（小->大）快速算区间 p
    区间 [a:b) 的 max = sizes[b-1]，sum 用前缀和
    """
    def __init__(self, job_size: np.ndarray, jobs_asc: List[int], S: float):
        self.job_size = job_size
        self.jobs = jobs_asc
        self.S = S
        self.sizes = job_size[jobs_asc]  # ascending
        self.pref = np.zeros(len(self.sizes) + 1)
        self.pref[1:] = np.cumsum(self.sizes)

    def seg_sum(self, a: int, b: int) -> float:
        # 计算size和
        return float(self.pref[b] - self.pref[a])

    def seg_p(self, a: int, b: int) -> float:
        # 计算批次加工时间
        # a<b
        max_s = float(self.sizes[b - 1])  # ascending: max at right end
        sum_s = self.seg_sum(a, b)
        return float(max_s * (1.0 + sum_s / self.S))


def split_into_2_balanced(job_size: np.ndarray, jobs_asc: List[int], S: float) -> List[List[int]]:
    """
    二划分：最小化 |p1-p2|
    输入 jobs_asc（小->大），输出两个子批（小->大，连续段切）
    """
    L = len(jobs_asc)
    if L <= 1:
        return [jobs_asc]

    H = SegmentHelper(job_size, jobs_asc, S)

    best_cut = 1
    best_obj = float("inf")

    for cut in range(1, L):  # part1=[0:cut), part2=[cut:L)
        p1 = H.seg_p(0, cut)
        p2 = H.seg_p(cut, L)
        obj = abs(p1 - p2)
        if obj < best_obj:
            best_obj = obj
            best_cut = cut

    return [jobs_asc[:best_cut], jobs_asc[best_cut:]]


def split_into_3_balanced(job_size: np.ndarray, jobs_asc: List[int], S: float) -> List[List[int]]:
    """
    三划分：让 p1,p2,p3 尽量接近
    目标：最小化 sum |p_i - mean|
    """
    L = len(jobs_asc)
    if L <= 2:
        return split_into_2_balanced(job_size, jobs_asc, S) if L == 2 else [jobs_asc]

    H = SegmentHelper(job_size, jobs_asc, S)

    best_w = 1
    best_e = 2
    best_range = float("inf")
    best_tie = float("inf")

    # 段1=[0:w), 段2=[w:e), 段3=[e:L)
    for w in range(1, L - 1):
        for e in range(w + 1, L):
            p1 = H.seg_p(0, w)
            p2 = H.seg_p(w, e)
            p3 = H.seg_p(e, L)

            mx = max(p1, p2, p3)
            mn = min(p1, p2, p3)
            rng = mx - mn

            # if  rng < best_range:
            #     best_range = rng
            #     best_w = w
            #     best_e = e

            mean = (p1 + p2 + p3) / 3.0
            tie = abs(p1 - mean) + abs(p2 - mean) + abs(p3 - mean)

            # if (rng < best_range) or (rng == best_range and tie < best_tie):
            if  tie < best_tie:
                # best_range = rng
                best_tie = tie
                best_w = w
                best_e = e

    return [jobs_asc[:best_w], jobs_asc[best_w:best_e], jobs_asc[best_e:]]


def split_into_k_balanced(
    job_size: np.ndarray,
    jobs_asc: List[int],
    k: int,
    S: float,
    max_moves: int = 20000,
) -> List[List[int]]:
    """
    k划分：
    - 将原始批 Bl=jobs_asc（按size小->大，连续段）划分成 k 个连续子批
    - 初始划分：num=floor(L/k)，余数添加批次 B1，其余每段长度=num
    - 迭代调整：每次找当：前 p 最大的批 idx_max 与最小的批 idx_min
        从 idx_max 向 idx_min 方向移动 1 个工件（只能通过移动相邻边界1格实现）
      并用两级准则更新“最优方案”：
        1) range = max(p)-min(p) 更小 优先
        2) range 相同，则 d = sum|p_i-avg| 更小 优先
    - “方案不变”理解为：若本次移动没改进，则 best 不更新；但 current 继续移动以探索后续状态，
      否则会卡在同一个不可改进动作上（无法继续）。
    """
    L = len(jobs_asc)
    if k <= 1 or L <= 1:
        return [jobs_asc]

    k = min(k, L)  # 每段至少1个

    # k=2/3 也可以走下面通用流程；若你想保留精确枚举，可取消注释两行
    if k == 2: return split_into_2_balanced(job_size, jobs_asc, S)
    if k == 3: return split_into_3_balanced(job_size, jobs_asc, S)

    H = SegmentHelper(job_size, jobs_asc, S)

    # ---------- 1) 初始 cuts：num=floor(L/k)，第一段吃余数 ----------
    num = L // k
    first_len = L - (k - 1) * num  # = num + r (r为余数)

    #cuts是长度为 k+1 的切点数组
    cuts = [0]
    idx = first_len
    cuts.append(idx)
    for _ in range(2, k + 1):
        idx += num
        cuts.append(idx)
    cuts[-1] = L  # 保险：最后必须到 L

    def p_list_from_cuts(cuts_local: List[int]) -> List[float]:
        #给定切点，算出k划分成k个批次对应的加工时间列表
        return [H.seg_p(cuts_local[i], cuts_local[i + 1]) for i in range(k)]

    def metrics(p_list: List[float]) -> Tuple[float, float]:
        # 返回 (range, d)
        mx = max(p_list)
        mn = min(p_list)
        rng = float(mx - mn)
        avg = float(sum(p_list) / k)
        d = float(sum(abs(p - avg) for p in p_list))
        return rng, d

    def build_parts_from_cuts(cuts_local: List[int]) -> List[List[int]]:
        #给定切点，把批切成k个子批
        return [jobs_asc[cuts_local[i]:cuts_local[i + 1]] for i in range(k)]

    # 当前方案 & 最优方案 ：批次处理时间、平均值、偏差
    cur_p = p_list_from_cuts(cuts)
    cur_rng, cur_d = metrics(cur_p)

    best_cuts = cuts.copy()
    best_rng, best_d = cur_rng, cur_d

    # 用 visited 防循环：
    # 把初始 cuts 转成 tuple 放进集合，后面如果某一步又回到以前出现过的 cuts，就停止（避免来回振荡）
    visited = {tuple(cuts)}

    # ---------- 2) 迭代：每次从 max 批向 min 批方向移动 1 个工件 ----------
    for _ in range(max_moves):
        # 重新计算当前 max/min（用当前方案）
        cur_p = p_list_from_cuts(cuts)
        idx_max = int(np.argmax(cur_p))
        idx_min = int(np.argmin(cur_p))

        if idx_max == idx_min:
            break  # 所有相同或只有一个批

        #如果最慢段在左边，最快段在右边：+1 向右移动
        #如果最慢段在右边，最快段在左边：-1 向左移动
        direction = 1 if idx_max < idx_min else -1
        donor = idx_max #捐出工件的批次
        recv = donor + direction    #捐出工件的相邻批次

        # 可行性：donor 至少2个工件，才能“移走1个仍非空”
        donor_len = cuts[donor + 1] - cuts[donor]
        if donor_len <= 1:
            # 退化处理：max 批不能再捐，就找“次大且可捐”的批（仍朝当前 idx_min 方向）
            order = np.argsort(-np.array(cur_p))  # p从大到小
            found = False
            for b in order:
                b = int(b)
                if b == idx_min:
                    continue
                dir2 = 1 if b < idx_min else -1
                recv2 = b + dir2
                if 0 <= recv2 < k and (cuts[b + 1] - cuts[b]) > 1:
                    donor = b
                    recv = recv2
                    direction = dir2
                    found = True
                    break
            if not found:
                break  # 没有人能移动了

        # 准备一个新的方案：执行“移动1个工件”（把一个工件从 donor 段移到相邻段 recv，只能改动它们之间那条边界）
        new_cuts = cuts.copy()

        if direction == 1:
            # donor 在左，向右移动：把 donor 的最后1个工件给右邻居
            # donor 段是：[cuts[donor], cuts[donor+1]) ; recv 段是：[cuts[donor+1], cuts[donor+2])
            # 等价 boundary = cuts[donor+1] 往左移 1 ：b -> b-1
            boundary = donor + 1
            # 向右移动一个工件，所以原来的max批的工件少1，切点想左移动1
            new_cuts[boundary] -= 1
        else:
            # donor 在右，向左移动：把 donor 的第1个工件给左邻居
            # 等价 boundary = cuts[donor] 往右移 1 ：a -> a+1
            boundary = donor
            # 切点向右移动 1
            new_cuts[boundary] += 1

        # 保证 cuts 单调且每段非空（强校验，防意外）
        ok = True
        for i in range(k):
            if not (new_cuts[i] < new_cuts[i + 1]):
                ok = False
                break
        if not ok:
            break

        # 防止循环：如果新方案以前出现过就停止
        tkey = tuple(new_cuts)
        if tkey in visited:
            break
        visited.add(tkey)

        # current 前进到新方案（用于下一轮继续移动）
        cuts = new_cuts

        # 评价并更新 best（你的准则：range 优先，其次 d）
        new_p = p_list_from_cuts(cuts)
        new_rng, new_d = metrics(new_p)

        if (new_rng < best_rng - 1e-12) or (abs(new_rng - best_rng) <= 1e-12 and new_d < best_d - 1e-12):
            best_rng, best_d = new_rng, new_d
            best_cuts = cuts.copy()

    # 返回 best 方案对应的 k 个连续子批（按原顺序）
    return build_parts_from_cuts(best_cuts)



def iterative_greedy_splitting(job_size_raw: np.ndarray, m: int, S: float, verbose: bool = False) -> Dict[str, Any]:
    """
    迭代贪婪主算法
    - 先DP得基础批
    - 基础批按 p 非递增排序为 base_batches = [B1,B2,...,Bk]
    - 每轮：把每个原始批按 split_cnt[base_id] 划分（2/3/k按新规则），合并成 current
    - 判断 max_p > sum_p/m ? 若成立：找 max_p 对应的 base_id，split_cnt[base_id]+=1
    - 直到不成立结束
    输出：最终批集合（含原始批编号、子批编号、长度、p、工件等）
    """
    job_size = np.asarray(job_size_raw, dtype=float)
    job_size = np.sort(job_size)  # SPT
    # print("Job Size:", job_size)

    # ① DP 得到单机最优组批（批内已经是升序/size非递减）
    sigma, B_asc, p_dp = dp_single_machine_batches(job_size, S)
    time1 = time.time()
    print(f"DP-BLPT运行时间= {time1 - start_time:.6f} 秒")

    print("========DP 得到单机最优组批：========")
    # print("Batches:", B_asc)
    # print("Batche Processing time:", p_dp)
    Cmax_SingleMachine = sum(p_dp)
    LowerBound = Cmax_SingleMachine / m
    print(f"Cmax_SingleMachine: {Cmax_SingleMachine :.6f}")
    print(f"LowerBound: Cmax_SM / m ={LowerBound:.6f}")
    print("初始批个数： ",len(p_dp))

    base_batches = B_asc[:]  # 批内保持“非递减”，不做额外排序

    # 按批处理时间 p 非递增排序得到 {B1,B2,...,Bk}
    base_batches.sort(key=lambda b: batch_p(job_size, b, S), reverse=True) #得到原始批次
    # 每个原始批当前划分份数（初始1）
    split_cnt = [1 for _ in base_batches]

    iter_log : List[Dict[str,Any]] = []
    it = 0

    while True:
        current = []
        #base_id：原始批索引 base：原始批本身
        for base_id, base in enumerate(base_batches):
            parts = split_into_k_balanced(job_size, base, split_cnt[base_id], S)
            #part_id：原始批k划分得到的k个子批索引 part：子批本身
            for part_id, part in enumerate(parts, start=1):
                current.append({
                    "base_id": base_id,
                    "original_B": base_id + 1,
                    "split_k": split_cnt[base_id],
                    "part_id": part_id,
                    "jobs": part,  # asc
                    "len": len(part),
                    "p": batch_p(job_size, part, S)
                })

        #所有子批排序按p降序
        current.sort(key=lambda x: x["p"], reverse=True)

        total_p = float(sum(x["p"] for x in current))
        avg = total_p / m
        max_p = float(current[0]["p"]) if current else 0.0
        cond = (max_p > avg + 1e-12)

        #将上一次迭代后的结果加入日志，并判断是否结束
        if verbose:
            iter_log.append({
                "iter": it,
                "split_cnt": split_cnt.copy(),
                "total_p": total_p,
                "avg": avg,
                "max_p": max_p,
                "condition_max_gt_avg": cond,
                "batches": [
                    {
                        "original_B": x["original_B"],
                        "part_id": x["part_id"],
                        "split_k": x["split_k"],
                        "len": x["len"],
                        "p": x["p"],
                        # 保证jobs按升序显示
                        "jobs": sorted(x["jobs"]),
                        "sizes": job_size[sorted(x["jobs"])].tolist()  # asc
                    } for x in current
                ]
            })

        # 停止：max_p <= Σp/m
        if max_p <= avg + 1e-12:
            break

        # 仍成立：找“当前最大子批”来自哪个原始批，split_cnt + 1
        chosen_base = int(current[0]["base_id"])

        # 若该原始批无法再细分（份数==长度），就找下一个“可细分且p最大”的批
        if split_cnt[chosen_base] >= len(base_batches[chosen_base]) or split_cnt[chosen_base]>m:
            found = False
            for item in current[1:]:
                b = int(item["base_id"])
                if split_cnt[b] < len(base_batches[b]):
                    chosen_base = b
                    found = True
                    break
            if not found:
                break

        split_cnt[chosen_base] += 1
        it += 1


    # 最终输出批集合（标注原始批编号/子批编号/长度/p/工件）
    final_batches = []
    for base_id, base in enumerate(base_batches):
        parts = split_into_k_balanced(job_size, base, split_cnt[base_id], S)
        for part_id, part in enumerate(parts, start=1):
            jobs_sorted = sorted((part))
            final_batches.append({
                "original_B": base_id + 1,
                "split_k": split_cnt[base_id],
                "part_id": part_id,
                "is_split": split_cnt[base_id] > 1,
                "jobs": jobs_sorted,  # asc
                "sizes": job_size[jobs_sorted].tolist(),  # asc
                "len": len(part),
                "p": batch_p(job_size, part, S)
            })

    final_batches.sort(key=lambda x: x["p"], reverse=True)

    res: Dict[str, Any] = {
        "sigma": sigma,
        "m": m,
        "S": S,
        "split_cnt_per_base_batch": split_cnt,
        "final_batches_sorted": final_batches,
        "final_batch_count": len(final_batches),
        "total_processing_time": float(sum(x["p"] for x in final_batches)),
        "avg_load": float(sum(x["p"] for x in final_batches)) / m,
        "max_batch_p": float(max(x["p"] for x in final_batches)) if final_batches else 0.0,
        "LowerBound": LowerBound,
    }
    if verbose:
        res["iter_log"] = iter_log
    return res

def print_iteration_log(res: Dict[str, Any], max_batches_to_show: int = None):
    """
        打印每次迭代的详细批集合（第二份代码专用）
        - jobs 使用 SPT(SSP) 后索引，且按升序显示
        """
    logs = res.get("iter_log", [])
    print(f"\n================ Iteration Logs (total {len(logs)}) ================\n")

    for log in logs:
        it = log["iter"]
        split_cnt = log["split_cnt"]
        total_p = log["total_p"]
        avg = log["avg"]
        max_p = log["max_p"]
        cond = log["condition_max_gt_avg"]
        batches = log["batches"]

        print("---------------------------------------------------------------------")
        print(f"Iter {it:02d}")
        print(f"  split_cnt per original batch B1..Bk = {split_cnt}")
        print(f"  Σp = {total_p:.6f} | Σp/m = {avg:.6f} | max_p = {max_p:.6f}")
        print(f"  condition max_p > Σp/m ?  {cond}")
        print("  Current batch set (sorted by p desc):")

        show = batches if (max_batches_to_show is None) else batches[:max_batches_to_show]
        for r, b in enumerate(show, start=1):
            if b["split_k"] > 1:
                tag = f"B{b['original_B']}(split->{b['split_k']}, part={b['part_id']})"
            else:
                tag = f"B{b['original_B']}(no_split)"

            print(
                f"    {r:02d} | {tag:22s} | len={b['len']:2d} | p={b['p']:.4f} | "
                f"jobs={b['jobs']} | sizes={np.round(b['sizes'], 6).tolist()}"
            )

        if (max_batches_to_show is not None) and (len(batches) > max_batches_to_show):
            print(f"    ... ({len(batches) - max_batches_to_show} more batches omitted)")

    print("\n================ End Logs ================\n")


def lpt_assign_batches_to_machines(final_batches_sorted: List[Dict[str, Any]], m: int) -> Dict[str, Any]:
    """
    LPT + List Scheduling:
    - final_batches_sorted: 批次已按 p 降序（LPT顺序）
    - 每个批次依次分配给当前负载最小的机器
    返回：每台机器的负载与分配细节、Cmax
    """
    # 机器负载
    loads = [0.0 for _ in range(m)]
    # 机器分配明细
    machines = [[] for _ in range(m)]

    for b in final_batches_sorted:
        # 选择当前负载最小的机器（并列取编号最小）
        i_min = min(range(m), key=lambda i: loads[i])

        # 分配该批次
        machines[i_min].append({
            "tag": f"B{b['original_B']}(part {b['part_id']}/{b['split_k']})" if b.get("is_split",
                                                                                      False) else f"B{b['original_B']}",
            "original_B": b["original_B"],
            "part_id": b["part_id"],
            "split_k": b["split_k"],
            "len": b["len"],
            "p": float(b["p"]),
            "jobs": b["jobs"],
            "sizes": b["sizes"],
            "start": loads[i_min],
            "finish": loads[i_min] + float(b["p"]),
        })
        loads[i_min] += float(b["p"])

    cmax = max(loads) if loads else 0.0
    return {"loads": loads, "machines": machines, "Cmax": cmax}


# ===================== 示例运行 =====================
if __name__ == "__main__":
    np.random.seed(42)
    n = 200
    m = 2
    S = 10.0
    # 直接生成(0, 10]之间的均匀分布，排除0
    job_size = np.random.uniform(low=1e-10, high=10.0, size=n)
    # 使用astype进行内存优化
    job_size = np.round(job_size, 3).astype(np.float32)
    job_size_raw = np.sort(job_size)
    # print(job_size_raw)


    #迭代贪婪模块
    start_time = time.time()
    res = iterative_greedy_splitting(job_size_raw, m=m, S=S, verbose=True)

    #将最终得到的批次通过LPT规则分配在m台机器上：
    final_batches = res["final_batches_sorted"]  # 已按 p 降序（LPT）
    assign_res = lpt_assign_batches_to_machines(final_batches, m=m)
    end_time = time.time()

    gap = (assign_res['Cmax']-res["LowerBound"]) / res["LowerBound"]
    print("\n========max_batch_p ≤ avg_load 成立时：========")
    print(f"将批次按照LPT规则分配：Cmax_LPT = {assign_res['Cmax']:.6f}")
    print("最终批次个数 =", res["final_batch_count"])
    print("total_p =", res["total_processing_time"])
    print("avg_load =", res["avg_load"])
    print("max_batch_p =", res["max_batch_p"])
    print(f"运行时间: {end_time - start_time:.6f} 秒")
    print(f"gap ={gap:.6f}")

    # print("\n========最终批次集合：========")
    # for i, b in enumerate(res["final_batches_sorted"], 1):
    #     tag = f"B{b['original_B']}"
    #     if b["is_split"]:
    #         tag += f"(split->{b['split_k']}, part={b['part_id']})"
    #     else:
    #         tag += "(no_split)"
    #     print(f"{i:02d} | {tag:22s} | len={b['len']:2d} | p={b['p']:.4f} | jobs={b['jobs']} | sizes={b['sizes']}")

    # # 打印每次迭代的详细批集合（全打印可能很长）
    # print_iteration_log(res, max_batches_to_show=None)

    # print("\n======== 将迭代贪婪的批次按照LPT规则分配在m台机器上：========")
    # print(f"Cmax (makespan) = {assign_res['Cmax']:.6f}")
    #
    # # 输出每台机器的负载与批次
    # for i, (load, seq) in enumerate(zip(assign_res["loads"], assign_res["machines"]), start=1):
    #     print(f"Machine {i:02d} | Load = {load:.6f} | #batches = {len(seq)}")
    #     for t, b in enumerate(seq, start=1):
    #         print(
    #             f"  {t:02d}. {b['tag']:18s} | p={b['p']:.4f} | "
    #             f"[{b['start']:.4f} -> {b['finish']:.4f}] | "
    #             f"len={b['len']:2d} | jobs={b['jobs']}"
    #         )


    print(f"gap= {gap:.6f}")
    print(f"gap = {gap * 100:.4f}%")
    # # 1.LS 多品种小批量
    # type_data = [
    #     (0.34, 301),
    #     (0.66, 431),
    #     (2.46, 476),
    #     (2.93, 373),
    #     (5.83, 435),
    #     (6.72, 485),
    #     (7.41, 366),
    #     (8.87, 380),
    #     (11.88, 395),
    #     (12.61, 343),
    #     (14.69, 470),
    #     (15.91, 300),
    #     (16.49, 350),
    #     (16.87, 497),
    #     (18.70, 458),
    #     (20.71, 396),
    #     (20.98, 399),
    #     (21.04, 454),
    #     (21.59, 482),
    #     (22.23, 474),
    #     (23.58, 352),
    #     (23.76, 328),
    #     (24.21, 354),
    #     (24.27, 309),
    #     (24.31, 328),
    #     (24.43, 484),
    #     (24.44, 441),
    #     (24.49, 391),
    #     (24.55, 482),
    #     (24.63, 361),
    #     (24.65, 433),
    #     (24.71, 317),
    #     (24.77, 370),
    #     (24.82, 339),
    #     (24.93, 304),
    #     (24.95, 315),
    #     (24.96, 335),
    #     (24.97, 435),
    #     (24.99, 373),
    #     (25.00, 346),
    # ]

    # # # 2. LPT 小品种大批量
    # type_data = [
    #     (5, 2594),
    #     (10, 3952),
    #     (15, 2332),
    #     (20, 4319),
    #     (25, 2389),
    # ]
    #
    # # 1) 展开成作业列表：每个Ni重复numi次
    # Ni_vals = np.array([x for x, c in type_data], dtype=np.float32)
    # numi_vals = np.array([c for x, c in type_data], dtype=np.int32)
    #
    # job_size = np.repeat(Ni_vals, numi_vals).astype(np.float32)
    #
    # job_size_raw = np.sort(job_size)
    # n = len(job_size)
    # m = 4
    # S = 30