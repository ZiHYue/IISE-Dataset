#!/usr/bin/env python
# coding=utf-8

import numpy as np
import time
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple


@dataclass
class Batch:
    jobs: List[int]          # 作业下标（0-based）
    p: float                 # 批处理时间


def batch_processing_time(job_size: np.ndarray, jobs: List[int], S: float) -> float:
    """p(B) = max{s_j} * (1 + sum{s_j}/S)"""
    sizes = job_size[jobs]
    return float(np.max(sizes) * (1.0 + np.sum(sizes) / S))


def dp_single_machine_batches(job_size: np.ndarray, S: float) -> Tuple[np.ndarray, List[List[int]], np.ndarray]:
    """
    单机DP：
    输出 sigma, B(批列表), p(每批处理时间)
    job_size 已经是非递减排序
    """
    n = len(job_size)
    f = np.zeros(n + 1)
    sigma = np.zeros(n + 1, dtype=int)

    # 初始化边界条件
    f[n] = 0.0      #边界条件：没有作业时处理时间为0
    sigma[n] = n    #边界条件：没有作业时结束位置为n

    # 预计算累积和数组以优化求和操作
    cumulative_sum = np.zeros(n + 1)
    cumulative_sum[1:] = np.cumsum(job_size)

    # 反向动态规划，从 k=n-1 到 k=0 反向计算
    for k in range(n - 1, -1, -1):
        si = k + 1
        fi = sigma[k + 1]

        # 处理边界情况
        if si > fi:
            f[k] = 0.0
            sigma[k] = si
            continue

        # 预计算每个可能区间的max_sj
        max_sj_values = np.maximum.accumulate(job_size[si - 1:fi])

        # 计算每个可能区间的fit值
        fit_values = np.zeros(fi - si + 1)
        for idx in range(fi - si + 1):
            current_i = si + idx
            max_sj = max_sj_values[idx]
            sum_si = cumulative_sum[current_i] - cumulative_sum[si - 1]
            batch_time = max_sj * (1.0 + sum_si / S)
            fit_values[idx] = batch_time + f[current_i]

        # 找到最小值和对应的索引
        min_idx = int(np.argmin(fit_values))
        f[k] = float(fit_values[min_idx])
        sigma[k] = si + min_idx

    # 回溯构造批
    B: List[List[int]] = []
    j = 0
    while j < n:
        bs = int(sigma[j])
        B.append(list(range(j, bs)))
        j = bs

    bn = len(B)
    p = np.zeros(bn)
    for b in range(bn):
        p[b] = batch_processing_time(job_size, B[b], S)

    Cmax_DP = np.sum(p)

    return sigma, B, p, Cmax_DP

def lpt_assign_batches_from_modified_dp_lpt(res: Dict[str, Any], m: int) -> Dict[str, Any]:
    """
    将 modified_dp_lpt 的最终“已接受批次”（res["machines"][i]["batches"]）取出，
    按 LPT（p 降序）重新分配到 m 台机器：每次放到当前负载最小的机器。
    输出：每台机器批次明细、负载、Cmax。
    """
    # -------- 1) 收集所有最终批次（来自 modified_dp_lpt 的 machines 输出）--------
    all_batches = []
    machines = res.get("machines", [])
    for mach in machines:
        for b in mach.get("batches", []):
            all_batches.append({
                "jobs_index": list(b["jobs_index"]),
                "jobs_size": list(b["jobs_size"]),
                "p": float(b["p"]),
                # 可选：保留原来在哪台机上（调试/对比用）
                "from_machine": int(mach.get("machine_id", -1)),
            })

    if len(all_batches) == 0:
        return {
            "Cmax": 0.0,
            "machines": [{"machine_id": i, "load": 0.0, "batches": []} for i in range(m)],
            "num_batches": 0
        }

    # -------- 2) LPT 排序：按批加工时间 p 从大到小 --------
    all_batches.sort(key=lambda x: x["p"], reverse=True)

    # -------- 3) 逐批分配到“当前负载最小”的机器 --------
    loads = [0.0 for _ in range(m)]
    assign = [[] for _ in range(m)]  # assign[i] = list of batch dicts

    for b in all_batches:
        i_min = int(np.argmin(loads))          # 当前负载最小机器
        assign[i_min].append(b)                # 把该批放进去
        loads[i_min] += b["p"]                 # 更新负载

    Cmax = float(max(loads))

    # -------- 4) 输出结构整理 --------
    machines_out = []
    for i in range(m):
        machines_out.append({
            "machine_id": i,
            "load": float(loads[i]),
            "batches": [
                {
                    "p": bb["p"],
                    "len": len(bb["jobs_index"]),
                    "jobs_index": bb["jobs_index"],
                    "jobs_size": bb["jobs_size"],
                    "from_machine": bb["from_machine"],
                } for bb in assign[i]
            ]
        })

    return {
        "Cmax": Cmax,
        "num_batches": len(all_batches),
        "machines": machines_out,
    }


def split_batch_to_meet_threshold(
    job_size: np.ndarray,
    batch_jobs: List[int],
    S: float,
    load_before: float,
    threshold: float
) -> Tuple[List[int], List[int]]:
    """
    在批内按非递减size（即批内jobs本身就从小到大）取出尽可能多的前缀，
    使得“留在机器上的后缀 keep_jobs”满足：
        load_before + p(keep_jobs) >= threshold
    且取出数量最大（keep_jobs尽量短，但非空）。
    返回: (take_out_jobs, keep_jobs)
    """
    L = len(batch_jobs)
    if L <= 1:
        return [], batch_jobs  # 无法拆

    # 预先计算后缀和，便于快速算 sum
    sizes = job_size[batch_jobs]    #一个sizes数组
    suffix_sum = np.zeros(L + 1)
    # suffix_sum[t] = sum sizes[t:]
    suffix_sum[L] = 0.0
    for t in range(L - 1, -1, -1):
        suffix_sum[t] = suffix_sum[t + 1] + sizes[t]    #用来表示（工件t~工件L-1）的size和

    # 由于批内最大值是最后一个作业（SPT且连续段），拆前缀不会改变max
    max_size = float(sizes[-1])

    best_t = 0  # 取出前缀长度t，keep = batch_jobs[t:]
    # 取最大t，使得 keep非空 且 load_before + p(keep) >= threshold
    for t in range(0, L):  # t=L-1 时 keep只剩最后1个作业，仍允许
        keep_len = L - t
        if keep_len <= 0:
            continue

        sum_keep = float(suffix_sum[t])
        p_keep = max_size * (1.0 + sum_keep / S)

        if load_before + p_keep >= threshold:
            best_t = t  # t越大取出越多
    #当机器负载恰好小于阈值时，停止给best_t赋值；此时后缀工件为{J_best_t,...,JL-1}
    take_out = batch_jobs[:best_t]  #前t个工件
    keep = batch_jobs[best_t:]      #从t到L-1的工件
    return take_out, keep


def modified_dp_lpt(job_size: np.ndarray, m: int, S: float) -> Dict[str, Any]:
    """
     modified DP-LPT：
      - 先DP得批{B1..Bk}
      - 反转逆向排序：{Bk..B1}
      - 计算 LB, Delta, threshold = Delta*LB
      - 逐批分配到最小负载机器；超过阈值时按规则拆批Bl并把拆出的新批插回队首{Bl',Bl-1..B1}
      - 同一台机器最多拆一次
    """
    job_size = np.asarray(job_size, dtype=float)
    job_size = np.sort(job_size)  # 确保SPT
    # print("Job Size:", job_size)


    sigma, B, p, Cmax_DP= dp_single_machine_batches(job_size, S)
    time1= time.time()
    print(f"DP-BLPT运行时间= {time1 - start_time:.6f} 秒")


    print("初始批个数： ",len(p))
    print("Cmax_DP_singleMachine:", Cmax_DP)

    print("LB = SumBl/m =", Cmax_DP/m)
    # print("Batches:", B)
    # print("Batche Processing time:", p)
    # ① 批按最大size非递增排序：直接反转
    B_queue: List[List[int]] = B[::-1]

    # ② 阈值
    s_max = float(np.max(job_size))
    LB = max(Cmax_DP / m, s_max * (1.0 + s_max / S))
    Delta = 1.0 + 1.0 / (1.0 + s_max / S)
    threshold = Delta * LB

    # 机器负载与分配结果
    mach_load = np.zeros(m, dtype=float)
    mach_split_used = np.zeros(m, dtype=bool)  # ⑤：每台机最多拆一次批次
    mach_batches: List[List[Batch]] = [[] for _ in range(m)]

    # ③-④：循环分配队列（拆出的批插回批次集合队首）
    while B_queue:
        batch_jobs = B_queue.pop(0)

        # 选当前负载最小机器
        mi = int(np.argmin(mach_load))
        load_before = float(mach_load[mi])

        # 计算该批的处理时间
        p_full = batch_processing_time(job_size, batch_jobs, S)
        load_after = load_before + p_full

        # 如果该机器未曾拆批、并且加上新批后的负载大于阈值
        if (not mach_split_used[mi]) and (load_after >= threshold):
            # 触发拆批
            take_out, keep = split_batch_to_meet_threshold(job_size, batch_jobs, S, load_before, threshold)

            if len(take_out) > 0:
                # 机器上只放 keep 这部分
                p_keep = batch_processing_time(job_size, keep, S)
                mach_load[mi] = load_before + p_keep
                mach_batches[mi].append(Batch(jobs=keep, p=p_keep))

                # 被取出的形成新批，按你要求插回队首：{Bl', Bl-1, ..., B1}
                B_queue.insert(0, take_out)

                # 标记该机已经拆过
                mach_split_used[mi] = True
            else:
                # 拆不了（取出任何一个都会使负载<threshold），那就整批放上去
                mach_load[mi] = load_after
                mach_batches[mi].append(Batch(jobs=batch_jobs, p=p_full))
        else:# 这种情况适用于 批次放在机器上的负载小于阈值
            # 不拆：直接整批放到该机
            mach_load[mi] = load_after
            mach_batches[mi].append(Batch(jobs=batch_jobs, p=p_full))

    Cmax = float(np.max(mach_load))



    # 输出整理：每台机的批明细（含作业size）
    machines_detail = []
    for i in range(m):
        batches_info = []
        for b in mach_batches[i]:
            sizes = job_size[b.jobs].tolist()
            batches_info.append({
                "jobs_index": b.jobs,
                "jobs_size": sizes,
                "p": b.p
            })
        machines_detail.append({
            "machine_id": i,
            "load": float(mach_load[i]),
            "split_used": bool(mach_split_used[i]),
            "batches": batches_info
        })

    return {
        "sigma": sigma,
        "dp_batches_B1_to_Bk": B,
        "dp_batches_p": p,
        "LB": LB,
        "Delta": Delta,
        "threshold": threshold,
        "Cmax": Cmax,
        "Cmax_DP": Cmax_DP,
        "machines": machines_detail,
        "batches_info":batches_info
    }


if __name__ == "__main__":
    np.random.seed(42)
    n = 200
    m = 2
    S = 10.0
    # 直接生成(0, 10]之间的均匀分布，排除0
    job_size = np.random.uniform(low=1e-10, high=10.0, size=n)
    # 使用astype进行内存优化
    job_size = np.round(job_size, 3).astype(np.float32)

    start_time = time.time()
    res = modified_dp_lpt(job_size, m=m, S=S)
    lpt_res = lpt_assign_batches_from_modified_dp_lpt(res, m=m)
    end_time =  time.time()
    LowerBound = res["Cmax_DP"]/m

    print()
    print("=== Part1：modified DP-LPT ===")
    # print("Cmax:", res["Cmax"])
    print(f"运行时间: {end_time - start_time:.6f} 秒")
    print("LB:", res["LB"])
    print("Delta:", res["Delta"])
    print("threshold = Delta*LB:", res["threshold"])
    # print(f"gap= {gap:.6f}")
    print()

    # print("========Part2：拆分过程：========")
    # for md in res["machines"]:
    #     print(f"Machine {md['machine_id']}: load={md['load']:.4f}, split_used={md['split_used']}")
    #     # for t, b in enumerate(md["batches"], 1):
    #     #     print(f"  Batch {t}: p={b['p']:.4f}, jobs={b['jobs_index']}")
    print()

    print("========Part3：modified-DP_LPT批次分配机器结果：========")
    print("num_batches:", lpt_res["num_batches"])
    # print("Cmax:", lpt_res["Cmax"])
    # # for mach in lpt_res["machines"]:
    # #     print(f"Machine {mach['machine_id']} : load={mach['load']:.4f}")
    # #     for t, b in enumerate(mach["batches"], 1):
    # #         print(f"   Batch{t} p={b['p']:.4f} | len={b['len']} | jobs={b['jobs_index']}")

    print("Cmax:", lpt_res["Cmax"])
    gap = (lpt_res["Cmax"] - LowerBound )/ LowerBound
    print(f"gap= {gap:.6f}")
    print(f"gap = {gap * 100:.4f}%")

# #1. LS 多品种小批量
    # type_data = [
    #     (0.34, 301),
    #     (0.66, 431),
    #     (2.46, 476),
    #     (2.93, 373),
    #     (5.83, 435),
    #     (6.72, 485),
    #     (7.41, 366),
    #     (8.87, 380),
    #     (11.88, 395),
    #     (12.61, 343),
    #     (14.69, 470),
    #     (15.91, 300),
    #     (16.49, 350),
    #     (16.87, 497),
    #     (18.70, 458),
    #     (20.71, 396),
    #     (20.98, 399),
    #     (21.04, 454),
    #     (21.59, 482),
    #     (22.23, 474),
    #     (23.58, 352),
    #     (23.76, 328),
    #     (24.21, 354),
    #     (24.27, 309),
    #     (24.31, 328),
    #     (24.43, 484),
    #     (24.44, 441),
    #     (24.49, 391),
    #     (24.55, 482),
    #     (24.63, 361),
    #     (24.65, 433),
    #     (24.71, 317),
    #     (24.77, 370),
    #     (24.82, 339),
    #     (24.93, 304),
    #     (24.95, 315),
    #     (24.96, 335),
    #     (24.97, 435),
    #     (24.99, 373),
    #     (25.00, 346),
    # ]

    # # 2. LPT 小品种大批量
    # type_data = [
    #     (5, 2594),
    #     (10, 3952),
    #     (15, 2332),
    #     (20, 4319),
    #     (25, 2389),
    # ]
    #
    # # 1) 展开成作业列表：每个Ni重复numi次
    # Ni_vals = np.array([x for x, c in type_data], dtype=np.float32)
    # numi_vals = np.array([c for x, c in type_data], dtype=np.int32)
    #
    # job_size = np.repeat(Ni_vals, numi_vals).astype(np.float32)
    #
    # job_size = np.sort(job_size)
    # n = len(job_size)
    # m = 4
    # S = 30