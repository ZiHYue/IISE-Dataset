"""
#!/usr/bin/env python
# coding=utf-8
@Author:Gongjie Xu
@Email:gjxu0928@gmail.com
@FileName:MINLP + Same Size.py
@DateTime:2025/7/1 18:35
@SoftWare:Pycharm
"""

import copy
from gurobipy import *
import matplotlib.pyplot as plt
import numpy as np
import time

# 颜色列表
color_type = ['red', 'orange', 'green', 'palegoldenrod', 'purple', 'pink', 'Thistle',
              'Magenta', 'SlateBlue', 'blue', 'RoyalBlue', 'Cyan', 'Aqua', 'floralwhite', 'ghostwhite',
              'goldenrod', 'mediumslateblue', 'navajowhite', 'navy', 'sandybrown', 'yellow', 'moccasin']

# 算例数据
n = 100 # 工件数量
m = 2   # 机器数量
L = 1000  # 增大M值

J = range(n)
M = range(m)
K = range(n)  # 批次数量，这里设置的为1至n最大批次数量

# 设置随机种子以便结果可重现
np.random.seed(42)
# 直接生成(0, 10]之间的均匀分布，排除0
js = np.random.uniform(low=1e-10, high=10.0, size=n)
# js = np.random.randint(low=1, high=10.0, size=n)
# 使用astype进行内存优化
js = np.round(js, 0).astype(np.float32)
# js = np.sort(js)
s = 10


# 生成索引

Index_X = [(j, k) for j in J for k in K]
Index_Y = [(k, i) for k in K for i in M]
Index_T = [k for k in K]


# 创建模型
model = Model("Pm_C-batch+Sj_Cmax")

# 生成变量，添加合理的上下界
x = model.addVars(Index_X, vtype=GRB.BINARY, name="x_j")
y = model.addVars(Index_Y, vtype=GRB.BINARY, name="y_j")
z = model.addVars(Index_T, vtype=GRB.CONTINUOUS, name="z_k")
p = model.addVars(Index_T, vtype=GRB.CONTINUOUS, name="p_k")
Cmax = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Cmax")

# 约束条件
model.addConstrs((quicksum(x[j, k] for k in K) == 1 for j in J), name="Con_x")
model.addConstrs((x[j1, k] == x[j2, k] for k in K for j1 in J for j2 in J if ((j1 != j2) and (js[j1] == js[j2]))), name="Con_x1")

model.addConstrs((quicksum(y[k, i] for i in M) == 1 for k in K), name="Con_y")

# 批次加工时间
for k in K:
    # 创建辅助变量来表示每个 js[j] * x[j, k]
    z_vars = []
    for j in J:
        z2 = model.addVar(lb=0, ub=js[j], name=f"z_{j}_{k}")  # z 范围为 0 到 js[j]
        model.addConstr(z2 <= js[j] * x[j, k], name=f"z_ub_{j}_{k}")  # z <= js[j] * x[j,k]
        model.addConstr(z2 >= js[j] * x[j, k] - js[j] * (1 - x[j, k]),
                        name=f"z_lb_{j}_{k}")  # z >= js[j]*x[j,k] - js[j]*(1-x[j,k])
        z_vars.append(z2)

    # 使用辅助变量列表
    max_s = model.addVar(vtype=GRB.CONTINUOUS, name=f"max_s_{k}")
    model.addGenConstrMax(max_s, z_vars, 0, f"max_s_{k}_constr")

    # 计算 ∑_{j∈J} s_j x_{jk}
    sum_s = quicksum(js[j] * x[j, k] for j in J)

    # 构建 ptt[k] 的约束
    model.addConstr(p[k] == max_s * (1 + sum_s / s), f"pt_{k}_constr")

# 目标函数
model.addConstrs((Cmax >= quicksum(y[k, i] * p[k] for k in K) for i in M), name="Con_Cmax")

# 优化设置
# model.setParam('NonConvex', 2)
model.setParam('OutputFlag', 1)
model.setParam('Heuristics', 0.8)
model.setParam('TimeLimit', 3600)
model.setParam('MIPGap', 0.0001)
model.setParam('Presolve', 2)
model.setParam('Cuts', 2)  # 增强割平面，默认值2，可按需调整
model.setParam('MIPFocus', 1)   # MIPFocus=1侧重快速找可行解，MIPFocus=2侧重最优性证明

model.setObjective(Cmax, sense=GRB.MINIMIZE)

# 开始计时
start_time = time.time()

# 优化模型
model.optimize()

# 结束计时
end_time = time.time()

# print(js)
# print("模型运行时间", end_time - start_time)
#
# for key in x.keys():
#     if x[key].x > 0.1:
#         print(x[key].VarName + ' = ', x[key].x)   #输出所有的决策变量
#
# for key in p.keys():
#     if p[key].x > 0.1:
#         print(p[key].VarName + ' = ', p[key].x)   #输出所有的决策变量

# 输出运行时间
print(f"运行时间: {end_time - start_time} 秒")

# # 状态检查
status = model.status
if status == GRB.Status.UNBOUNDED:
    print('The model cannot be solved because it is unbounded')
    exit(0)
if status == GRB.Status.OPTIMAL:
    print('The optimal objective is %g' % model.objVal)
    exit(0)
if status != GRB.Status.INF_OR_UNBD and status != GRB.Status.INFEASIBLE:
    print('Optimization was stopped with status %d' % status)
    exit(0)

# do IIS
print('The model is infeasible; computing IIS')
model.computeIIS()
if model.IISMinimal:
    print('IIS is minimal\n')
else:
    print('IIS is not minimal\n')
print('\nThe following constraint(s) cannot be satisfied:')
for c in model.getConstrs():
    if c.IISConstr:
        print('%s' % c.constrName)
