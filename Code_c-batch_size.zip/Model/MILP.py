"""
#!/usr/bin/env python
# coding=utf-8
@Author:Gongjie Xu
@Email:gjxu0928@gmail.com
@FileName:Linear Model-C-batch-Cmax.py
@DateTime:2025/6/26 19:48
@SoftWare:Pycharm
"""

import copy
from gurobipy import *
import matplotlib.pyplot as plt
import numpy as np
import time

# 颜色列表
color_type = ['red', 'orange', 'green', 'palegoldenrod', 'purple', 'pink', 'Thistle',
              'Magenta', 'SlateBlue', 'blue', 'RoyalBlue', 'Cyan', 'Aqua', 'floralwhite', 'ghostwhite',
              'goldenrod', 'mediumslateblue', 'navajowhite', 'navy', 'sandybrown', 'yellow', 'moccasin']

# 算例数据

m = 2  # 机器数量
n = 100 # 工件数量
J = range(n)
M = range(m)
K = range(n)  # 批次数量，这里设置的为1至n最大批次数量

# 设置随机种子以便结果可重现
np.random.seed(42)
# 直接生成(0, 10]之间的均匀分布，排除0
js = np.random.uniform(low=1e-10, high=10.0, size=n)
# js = np.random.randint(low=1, high=10.0, size=n)
# 使用astype进行内存优化
js = np.round(js, 3).astype(np.float32)
# js = np.sort(js)
S = 10

# js = np.array([1.00, 1.00, 1.00, 0.50, 0.50, 0.50, 0.50, 0.50, 0.50, 0.50, 0.50, 0.50, 0.50, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.33, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.20, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.17, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14, 0.14])
# js = np.sort(js)
# n = 173
# s = 1

L = np.max(js) * (1 + np.sum(js)/S)  # 增大M值

# L = 1000

# 生成索引
Index_X = [(j, k) for j in J for k in K]
Index_Y = [(k, i) for k in K for i in M]
Index_T = [k for k in K]

# 创建模型
model = Model("Pm_C-batch+Sj_Cmax")

# 生成变量，添加合理的上下界
x = model.addVars(Index_X, vtype=GRB.BINARY, name="x_jk")
w = model.addVars(Index_X, vtype=GRB.CONTINUOUS, name="w_jk")
y = model.addVars(Index_Y, vtype=GRB.BINARY, name="y_ki")
u = model.addVars(Index_Y, vtype=GRB.CONTINUOUS, name="u_ki")
z = model.addVars(Index_T, lb=0, ub=max(js), vtype=GRB.CONTINUOUS, name="z_k")
p = model.addVars(Index_T, vtype=GRB.CONTINUOUS, name="p_k")
Cmax = model.addVar(lb=0, vtype=GRB.CONTINUOUS, name="Cmax")

# 添加约束
model.addConstrs((quicksum(x[j, k] for k in K) == 1 for j in J), name="Con_x")

model.addConstrs((quicksum(y[k, i] for i in M) == 1 for k in K), name="Con_y")

model.addConstrs((z[k] >= js[j] * x[j, k] for k in K for j in J), name="Con_z1")

model.addConstrs((w[j, k] <= z[k] for k in K for j in J), name="Con_w1")

model.addConstrs((w[j, k] <= S * x[j, k] for k in K for j in J), name="Con_w2")

model.addConstrs((w[j, k] >= z[k] - S * (1 - x[j, k]) for k in K for j in J), name="Con_w3")

model.addConstrs((p[k] >= z[k] + quicksum(js[j] * w[j, k] for j in J) / S for k in K), name="Con_p1")
model.addConstrs((p[k] <= z[k] + quicksum(js[j] * w[j, k] for j in J) / S for k in K), name="Con_p2")

model.addConstrs((u[k, i] <= p[k] for k in K for i in M), name="Con_u1")

model.addConstrs((u[k, i] <= L * y[k, i] for k in K for i in M), name="Con_u2")

model.addConstrs((u[k, i] >= p[k] - L * (1 - y[k, i]) for k in K for i in M), name="Con_u3")

model.addConstrs((Cmax >= quicksum(u[k, i] for k in K) for i in M), name="Con_Cmax")

# 优化设置
# model.setParam('NonConvex', 2)
model.setParam('OutputFlag', 1)
model.setParam('Heuristics', 0.8)
model.setParam('TimeLimit', 3600)
model.setParam('MIPGap', 0.0001)
model.setParam('Presolve', 2)
model.setParam('Cuts', 2)  # 增强割平面，默认值2，可按需调整
model.setParam('MIPFocus', 1)   # MIPFocus=1侧重快速找可行解，MIPFocus=2侧重最优性证明

# 确定优化目标是什么
model.setObjective(Cmax, sense=GRB.MINIMIZE)

# 开始计时
start_time = time.time()

# 优化模型
model.optimize()

# 结束计时
end_time = time.time()

# print(js)

# for key in x.keys():
#     if x[key].x > 0.1:
#         print(x[key].VarName + ' = ', x[key].x)   #输出所有的决策变量
#
# for key in p.keys():
#     if p[key].x > 0.1:
#         print(p[key].VarName + ' = ', p[key].x)   #输出所有的决策变量

# 输出运行时间
print(f"运行时间: {end_time - start_time} 秒")

# # 状态检查
status = model.status
if status == GRB.Status.UNBOUNDED:
    print('The model cannot be solved because it is unbounded')
    exit(0)
if status == GRB.Status.OPTIMAL:
    print('The optimal objective is %g' % model.objVal)
    exit(0)
if status != GRB.Status.INF_OR_UNBD and status != GRB.Status.INFEASIBLE:
    print('Optimization was stopped with status %d' % status)
    exit(0)

# do IIS
print('The model is infeasible; computing IIS')
model.computeIIS()
if model.IISMinimal:
    print('IIS is minimal\n')
else:
    print('IIS is not minimal\n')
print('\nThe following constraint(s) cannot be satisfied:')
for c in model.getConstrs():
    if c.IISConstr:
        print('%s' % c.constrName)



