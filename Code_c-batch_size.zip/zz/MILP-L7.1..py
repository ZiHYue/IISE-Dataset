#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""112,000件周工作量的单机 MILP-L（同尺寸工件不可拆分）。"""

from __future__ import annotations

import time

import gurobipy as gp
from gurobipy import GRB


S = 30.0
TIME_LIMIT = 3600.0
MIP_GAP = 1e-4

# 与DP和MINLP-L周实验完全相同的数据。
TYPE_DATA = [
    (6.2, 700, "small"),
    (8.4, 700, "small"),
    (10.6, 700, "small"),
    (12.8, 700, "small"),
    (15.1, 700, "small"),
    (17.3, 700, "small"),
    (20.0, 700, "small"),
    (23.4, 700, "small"),
    (26.7, 700, "small"),
    (29.2, 700, "small"),
    (5.0, 21000, "large"),
    (7.0, 21000, "large"),
    (9.0, 21000, "large"),
    (11.0, 21000, "large"),
    (13.0, 21000, "large"),
]


def validate_data(type_data):
    if not type_data:
        raise ValueError("TYPE_DATA不能为空")
    if any(size <= 0 or size > S for size, _, _ in type_data):
        raise ValueError("所有工件尺寸必须位于(0,S]内")
    if any(count <= 0 for _, count, _ in type_data):
        raise ValueError("所有工件数量必须大于0")
    total_jobs = sum(count for _, count, _ in type_data)
    if total_jobs != 112000:
        raise ValueError(f"周工件总数应为112000，当前为{total_jobs}")


def build_and_solve(type_data):
    validate_data(type_data)
    ordered = sorted(type_data, key=lambda row: row[0])
    sizes = [float(row[0]) for row in ordered]
    counts = [int(row[1]) for row in ordered]
    categories = [str(row[2]) for row in ordered]

    type_count = len(ordered)
    max_batch_count = type_count
    T = range(type_count)
    K = range(max_batch_count)
    big_m = max(sizes)

    model = gp.Model("MILP_L_weekly_single_machine")

    # x[t,k]=1：尺寸类型t整体分配到批次k。
    x = model.addVars(T, K, vtype=GRB.BINARY, name="x")
    used = model.addVars(K, vtype=GRB.BINARY, name="used")
    z = model.addVars(K, lb=0.0, ub=big_m, name="max_size")
    # w[t,k] = z[k] * x[t,k]。
    w = model.addVars(T, K, lb=0.0, ub=big_m, name="w")
    p = model.addVars(K, lb=0.0, name="p")
    cmax = model.addVar(lb=0.0, name="Cmax")

    # 每种尺寸的全部工件恰好进入一个批次。
    model.addConstrs(
        (gp.quicksum(x[t, k] for k in K) == 1 for t in T),
        name="assign_type_once",
    )

    # 批次启用关系。
    model.addConstrs(
        (x[t, k] <= used[k] for t in T for k in K),
        name="activate_batch",
    )
    model.addConstrs(
        (gp.quicksum(x[t, k] for t in T) >= used[k] for k in K),
        name="used_batch_nonempty",
    )

    # z[k]为批次k中的最大尺寸；目标最小化会使其取紧。
    model.addConstrs(
        (z[k] >= sizes[t] * x[t, k] for t in T for k in K),
        name="max_size_lb",
    )
    model.addConstrs(
        (z[k] <= big_m * used[k] for k in K),
        name="max_size_zero_if_unused",
    )

    # Big-M线性化 w[t,k] = z[k] * x[t,k]。
    model.addConstrs(
        (w[t, k] <= z[k] for t in T for k in K),
        name="linear_w_1",
    )
    model.addConstrs(
        (w[t, k] <= big_m * x[t, k] for t in T for k in K),
        name="linear_w_2",
    )
    model.addConstrs(
        (
            w[t, k] >= z[k] - big_m * (1 - x[t, k])
            for t in T for k in K
        ),
        name="linear_w_3",
    )

    # p(B)=max_size*(1+sum_size/S)
    #      =z + sum_t(count_t*size_t*w_tk)/S。
    model.addConstrs(
        (
            p[k]
            == z[k]
            + gp.quicksum(counts[t] * sizes[t] * w[t, k] for t in T) / S
            for k in K
        ),
        name="processing_time",
    )

    # 单机环境：Cmax为所有批次加工时间之和。
    model.addConstr(cmax == gp.quicksum(p[k] for k in K), name="cmax_def")

    # 对称性消除：非空批次在前，并按最大尺寸非增编号。
    model.addConstrs(
        (used[k] >= used[k + 1] for k in range(max_batch_count - 1)),
        name="used_order",
    )
    model.addConstrs(
        (z[k] >= z[k + 1] for k in range(max_batch_count - 1)),
        name="max_size_order",
    )

    model.setObjective(cmax, GRB.MINIMIZE)

    model.Params.OutputFlag = 1
    model.Params.Heuristics = 0.8
    model.Params.TimeLimit = TIME_LIMIT
    model.Params.MIPGap = MIP_GAP
    model.Params.Presolve = 2
    model.Params.Cuts = 2
    model.Params.MIPFocus = 1

    # 提供“每种尺寸单独成批”的高质量初始解。
    descending_types = sorted(T, key=lambda t: sizes[t], reverse=True)
    for k in K:
        used[k].Start = 1.0
        for t in T:
            x[t, k].Start = 1.0 if t == descending_types[k] else 0.0

    start = time.perf_counter()
    model.optimize()
    elapsed = time.perf_counter() - start

    return {
        "model": model,
        "elapsed": elapsed,
        "sizes": sizes,
        "counts": counts,
        "categories": categories,
        "x": x,
        "used": used,
        "z": z,
        "p": p,
        "cmax": cmax,
        "T": T,
        "K": K,
    }


def print_result(result):
    model = result["model"]
    print("\n=== MILP-L result ===")
    print(f"Status = {model.Status}")
    print(f"Runtime measured by Python = {result['elapsed']:.6f} seconds")
    print(f"Gurobi Runtime = {model.Runtime:.6f} seconds")

    if model.SolCount == 0:
        print("在时间限制内没有找到可行解。")
        return

    print(f"Cmax = {result['cmax'].X:.6f} seconds")
    print(f"Cmax = {result['cmax'].X / 3600.0:.6f} hours")
    print(f"Best bound = {model.ObjBound:.6f}")
    print(f"MIP gap = {model.MIPGap * 100:.6f}%")

    nonempty_batches = []
    for k in result["K"]:
        if result["used"][k].X > 0.5:
            members = [
                t for t in result["T"]
                if result["x"][t, k].X > 0.5
            ]
            nonempty_batches.append((k, members))

    print(f"Batch count = {len(nonempty_batches)}")
    for sequence, (k, members) in enumerate(nonempty_batches, start=1):
        member_text = [
            (
                result["sizes"][t],
                result["counts"][t],
                result["categories"][t],
            )
            for t in members
        ]
        total_size = sum(
            result["sizes"][t] * result["counts"][t]
            for t in members
        )
        print(
            f"B{sequence:02d}: types={member_text}, "
            f"max_size={result['z'][k].X:.1f}, "
            f"total_size={total_size:.1f}, "
            f"p={result['p'][k].X:.6f}"
        )


def main():
    result = build_and_solve(TYPE_DATA)
    print_result(result)


if __name__ == "__main__":
    main()
