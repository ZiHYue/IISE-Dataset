#!/usr/bin/env python
# coding=utf-8

"""Run FBLPT on 50 independently generated instances.

The random-instance settings and the lower-bound calculation are consistent
with BLPT-manyexperients.py and BLS-manyexperients.py.
"""

import time
from typing import Dict, List, Sequence, Tuple

import numpy as np


EPS = 1e-9


def generate_jobs(
    n: int,
    seed: int,
    s: float = 30.0,
) -> np.ndarray:
    """Generate the same five-jobs-per-size instance used by BLS."""
    if n % 5 != 0:
        raise ValueError(
            "The number of jobs n must be divisible by 5 so that each job type "
            "appears exactly five times."
        )

    num_job_types = n // 5
    candidate_sizes = np.round(np.arange(0.1, s + 0.1, 0.1), 1)
    if num_job_types > len(candidate_sizes):
        raise ValueError(
            f"At most {5 * len(candidate_sizes)} jobs are supported when distinct sizes "
            "are retained to one decimal place in (0.0, 30.0]."
        )

    np.random.seed(seed)
    job_type_sizes = np.random.choice(
        candidate_sizes, size=num_job_types, replace=False
    )
    js = np.tile(job_type_sizes, 5)
    js = js.astype(np.float32)
    return np.sort(js)

def dp_single_machine_value(job_size: np.ndarray, S: float) -> float:
    """Return the single-machine DP value used to form the common lower bound."""
    sizes = np.sort(np.asarray(job_size, dtype=float))
    n = len(sizes)

    f = np.zeros(n + 1, dtype=float)
    sigma = np.zeros(n + 1, dtype=int)
    sigma[n] = n

    prefix_sum = np.zeros(n + 1, dtype=float)
    prefix_sum[1:] = np.cumsum(sizes)

    # This recurrence is kept consistent with the two reference scripts.
    for k in range(n - 1, -1, -1):
        first_end = k + 1
        last_end = int(sigma[k + 1])

        candidate_values = np.empty(last_end - first_end + 1, dtype=float)
        for offset, end in enumerate(range(first_end, last_end + 1)):
            max_size = sizes[end - 1]
            sum_size = prefix_sum[end] - prefix_sum[k]
            candidate_values[offset] = (
                max_size * (1.0 + sum_size / S) + f[end]
            )

        best_offset = int(np.argmin(candidate_values))
        f[k] = candidate_values[best_offset]
        sigma[k] = first_end + best_offset

    return float(f[0])


def form_fblpt_batches(
    job_size: np.ndarray,
    S: float,
) -> List[Dict[str, object]]:
    """Form batches greedily in nonincreasing job-size order."""
    if S <= 0:
        raise ValueError("S must be positive.")

    sizes = np.asarray(job_size, dtype=float)
    if np.any(sizes <= 0):
        raise ValueError("All job sizes must be positive.")
    if np.any(sizes > S + EPS):
        raise ValueError("Every job size must be no greater than S.")

    order = np.argsort(-sizes, kind="stable")
    raw_batches: List[List[int]] = []
    current_batch: List[int] = []
    current_sum = 0.0

    for job_index in order:
        size = float(sizes[job_index])
        if current_batch and current_sum + size > S + EPS:
            raw_batches.append(current_batch)
            current_batch = []
            current_sum = 0.0

        current_batch.append(int(job_index))
        current_sum += size

    if current_batch:
        raw_batches.append(current_batch)

    batches: List[Dict[str, object]] = []
    for batch_id, jobs in enumerate(raw_batches, start=1):
        batch_sizes = sizes[jobs]
        sum_size = float(np.sum(batch_sizes))
        max_size = float(np.max(batch_sizes))
        processing_time = max_size * (1.0 + sum_size / S)
        batches.append(
            {
                "batch_id": batch_id,
                "jobs": jobs,
                "processing_time": processing_time,
            }
        )

    return batches


def lpt_assign(
    batches: Sequence[Dict[str, object]],
    machine_num: int,
) -> Tuple[float, List[float]]:
    """Assign FBLPT batches to the currently least-loaded machine by LPT."""
    if machine_num <= 0:
        raise ValueError("machine_num must be a positive integer.")

    ordered_batches = sorted(
        batches,
        key=lambda batch: (
            -float(batch["processing_time"]),
            int(batch["batch_id"]),
        ),
    )

    loads = [0.0] * machine_num
    for batch in ordered_batches:
        machine = min(range(machine_num), key=lambda i: (loads[i], i))
        loads[machine] += float(batch["processing_time"])

    return max(loads, default=0.0), loads


def solve_fblpt(
    job_size: np.ndarray,
    S: float,
    machine_num: int,
) -> Tuple[float, int, List[float]]:
    """Execute FBLPT batching followed by LPT machine assignment."""
    batches = form_fblpt_batches(job_size, S)
    Cmax, loads = lpt_assign(batches, machine_num)
    return Cmax, len(batches), loads


def run_50_experiments(
    n: int,
    m: int,
    S: float,
    first_seed: int = 101,
    number_of_instances: int = 50,
) -> List[Dict[str, float]]:
    """Run and print 50 independent instances under identical conditions."""
    results: List[Dict[str, float]] = []
    total_start = time.perf_counter()

    for seed in range(first_seed, first_seed + number_of_instances):
        job_size = generate_jobs(n=n, seed=seed, s=S)

        instance_start = time.perf_counter()
        Cmax_DP = dp_single_machine_value(job_size, S)
        lower_bound = Cmax_DP / m
        Cmax, batch_count, _ = solve_fblpt(job_size, S, m)
        cpu_time = time.perf_counter() - instance_start

        gap = (Cmax - lower_bound) / lower_bound
        result = {
            "seed": float(seed),
            "Cmax": Cmax,
            "CPU_time": cpu_time,
            "batch_count": float(batch_count),
            "gap": gap,
            "LB": lower_bound,
        }
        results.append(result)

        # One output line for each of the 50 instances.
        print(
            # f"{Cmax:.3f}/{cpu_time:.6f}s/"
            f"{Cmax:.3f}/"
            f"{gap * 100:.4f}%/{lower_bound:.3f}"
        )

    total_time = time.perf_counter() - total_start
    mean_Cmax = float(np.mean([r["Cmax"] for r in results]))
    mean_cpu = float(np.mean([r["CPU_time"] for r in results]))
    mean_gap = float(np.mean([r["gap"] for r in results]))
    mean_LB = float(np.mean([r["LB"] for r in results]))

    print("\nAverage over 50 instances:")
    print(
        f"{mean_Cmax:.3f}/"
        f"{mean_gap * 100:.4f}%/{mean_LB:.3f}"
    )
    print(f"Total running time: {total_time:.6f} s")
    return results


if __name__ == "__main__":
    # Keep these settings identical to BLS-manyexperients.py.
    M = 2
    CHAMBER_LENGTH = 30.0

    for N in (100, 120, 140, 160, 180, 200):
        print("m=", M, ",n=", N)
        run_50_experiments(
            n=N,
            m=M,
            S=CHAMBER_LENGTH,
            first_seed=101,
            number_of_instances=50,
        )
