#!/usr/bin/env python
# coding=utf-8

import numpy as np
import time


def DP_C_batch(job_size, n, S):
    f = np.zeros(n + 1)
    sigma = np.zeros(n + 1, dtype=int)
    B = []

    # 边界条件
    f[n] = 0
    sigma[n] = n

    # 累积和
    cumulative_sum = np.zeros(n + 1)
    cumulative_sum[1:] = np.cumsum(job_size)

    # 反向DP
    for k in range(n - 1, -1, -1):
        si = k + 1
        fi = sigma[k + 1]

        if si > fi:
            f[k] = 0
            sigma[k] = si
            continue

        # 预计算 max_sj（从 si 到每个可能的 current_i 的最大值）
        max_sj_values = np.maximum.accumulate(job_size[si - 1:fi])

        fit_values = np.zeros(fi - si + 1)
        for i in range(fi - si + 1):
            current_i = si + i
            max_sj = max_sj_values[i]
            sum_si = cumulative_sum[current_i] - cumulative_sum[si - 1]
            fit_values[i] = max_sj * (1 + sum_si / S) + f[current_i]

        min_idx = np.argmin(fit_values)
        f[k] = fit_values[min_idx]
        sigma[k] = si + min_idx

    # 构建批次 B（用作业下标区间表示）
    j = 0
    while j < n:
        bs = sigma[j]
        B.append(np.arange(j, bs).tolist())
        j = bs

    # 计算每个批次加工时间 p[b]
    bn = len(B)
    p = np.zeros(bn)
    for b in range(bn):
        p[b] = max(job_size[B[b]]) * (1 + sum(job_size[B[b]]) / S)

    # 单机情形下，DP目标对应的总时间（这里你原代码叫 Cmax，但它是 sum p）
    Cmax_single = float(np.sum(p))
    return sigma, B, p, Cmax_single


def lpt_assign_batches(B, p, m):
    """
    按 LPT 规则将批次分配到 m 台机器：
    1) 批次按加工时间 p 非递增排序
    2) 依次分配到当前负载最小的机器
    返回：Cmax_multi, loads, assignment
      - loads[i]: 第 i 台机器总负载
      - assignment[i]: [(batch_id, p_time, jobs_in_batch), ...]
    """
    bn = len(B)
    order = sorted(range(bn), key=lambda b: p[b], reverse=True)

    loads = [0.0] * m
    assignment = [[] for _ in range(m)]

    for b in order:
        i = min(range(m), key=lambda t: loads[t])  # 当前负载最小
        loads[i] += float(p[b])
        assignment[i].append((b, float(p[b]), B[b]))

    Cmax_multi = max(loads) if loads else 0.0
    return Cmax_multi, loads, assignment

if __name__ == "__main__":
    # n = 10000
    m = 2
    s = 30.0

    for n in (100, 120, 140, 160, 180, 200):
        total_start_time = time.time()
        results = []
        print("m=", m, ",n=", n)
        for seed in range(101, 151):
            np.random.seed(seed)

            # 先在 (0.0, 30.0] 内随机生成 n/5 种工件尺寸，并保留一位小数；
            # 然后将每种工件复制四份并与原集合拼接，使每种尺寸恰好对应五个工件。
            if n % 5 != 0:
                raise ValueError(
                    "The number of jobs n must be divisible by 5 so that each job type "
                    "appears exactly five times."
                )

            num_job_types = n // 5
            candidate_sizes = np.round(np.arange(0.1, s + 0.1, 0.1), 1)
            if num_job_types > len(candidate_sizes):
                raise ValueError(
                    f"At most {5 * len(candidate_sizes)} jobs are supported when distinct sizes "
                    "are retained to one decimal place in (0.0, 30.0]."
                )

            # 从 0.1, 0.2, ..., 30.0 中无放回抽取，确保 n/5 个工件种类互不相同。
            job_type_sizes = np.random.choice(
                candidate_sizes, size=num_job_types, replace=False
            )

            # 保留原始集合，并整体复制四份，拼接为包含 n 个工件的初始输入集合。
            js = np.tile(job_type_sizes, 5)
            js = js.astype(np.float32)
            js = np.sort(js)

            # 求解前可输出本次实验的全部输入工件。
            # print("All jobs:", js)

            L = np.max(js) * (1 + np.sum(js) / s)  # 增大M值

            sigma, B, p, Cmax_single = DP_C_batch(js, n, s)
            LB = Cmax_single / m

            Cmax_multi, loads, assignment = lpt_assign_batches(B, p, m)
            gap = (Cmax_multi - LB) / LB
            gap_percent = gap * 100

            results.append((Cmax_multi, gap_percent, LB))
            print(f"{Cmax_multi:.3f}/{gap_percent:.4f}%/{LB:.3f}")

        average_cmax, average_gap_percent, average_lb = np.mean(results, axis=0)
        total_end_time = time.time()
        print(
            f"平均值: {average_cmax:.3f}/"
            f"{(total_end_time - total_start_time) / 50:.3f}/"
            f"0/{average_gap_percent:.4f}%/{average_lb:.3f}"
        )
