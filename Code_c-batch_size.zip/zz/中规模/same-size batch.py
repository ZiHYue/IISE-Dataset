#!/usr/bin/env python
# coding=utf-8

import numpy as np
import time


def generate_jobs(
    n: int,
    seed: int,
    s: float = 30.0,
) -> np.ndarray:
    """生成与 FBLS 相同的实例：每种尺寸恰好包含五个工件。"""
    if n % 5 != 0:
        raise ValueError(
            "The number of jobs n must be divisible by 5 so that each job type "
            "appears exactly five times."
        )

    num_job_types = n // 5
    candidate_sizes = np.round(np.arange(0.1, s + 0.1, 0.1), 1)
    if num_job_types > len(candidate_sizes):
        raise ValueError(
            f"At most {5 * len(candidate_sizes)} jobs are supported when distinct sizes "
            "are retained to one decimal place in (0.0, 30.0]."
        )

    np.random.seed(seed)
    job_type_sizes = np.random.choice(
        candidate_sizes, size=num_job_types, replace=False
    )
    js = np.tile(job_type_sizes, 5)
    js = js.astype(np.float32)
    return np.sort(js)

def dp_single_machine_value(job_size: np.ndarray, S: float) -> float:
    """计算与 FBLS 相同的单机 DP 值，用于构造公共下界。"""
    sizes = np.sort(np.asarray(job_size, dtype=float))
    n = len(sizes)

    f = np.zeros(n + 1, dtype=float)
    sigma = np.zeros(n + 1, dtype=int)
    sigma[n] = n

    prefix_sum = np.zeros(n + 1, dtype=float)
    prefix_sum[1:] = np.cumsum(sizes)

    for k in range(n - 1, -1, -1):
        first_end = k + 1
        last_end = int(sigma[k + 1])

        candidate_values = np.empty(last_end - first_end + 1, dtype=float)
        for offset, end in enumerate(range(first_end, last_end + 1)):
            max_size = sizes[end - 1]
            sum_size = prefix_sum[end] - prefix_sum[k]
            candidate_values[offset] = (
                max_size * (1.0 + sum_size / S) + f[end]
            )

        best_offset = int(np.argmin(candidate_values))
        f[k] = candidate_values[best_offset]
        sigma[k] = first_end + best_offset

    return float(f[0])

def same_size_batch_lpt(job_size, n, S, machine_num):
    """
    按 size 非减排序 + 相邻相同 size 组批 + LPT 多机调度

    规则：
    1. 输入中每种工件尺寸恰好出现五次；
    2. 所有工件按照 size 非减顺序排序；
    3. 从前到后依次比较相邻工件：
       - 若相邻工件 size 相同，则组成同一个批次；
       - 若 size 不同，则结束当前批次并开启新批次；
    4. 每个批次加工时间：
           p(B) = size * (total_size + S) / S
       其中 total_size 为该批次内所有工件 size 之和；
    5. 将批次按照加工时间 p(B) 非增排序；
    6. 按照 LPT 规则依次分配到当前负载最小的机器；
    7. Cmax = 最大机器负载。
    """

    if n != len(job_size):
        raise ValueError("n 与 job_size 的长度不一致！")
    if S <= 0:
        raise ValueError("S 必须大于 0！")
    if machine_num <= 0:
        raise ValueError("machine_num 必须大于 0！")

    # ==========================================================
    # 1. 将所有工件按照 size 非减排序
    # ==========================================================
    # 使用 stable 排序：size 相同时保持原工件编号的先后顺序
    sorted_indices = np.argsort(job_size, kind="stable")
    sorted_job_size = job_size[sorted_indices]

    # ==========================================================
    # 2. 比较排序后相邻工件的 size，连续相同 size 组成一个批次
    # ==========================================================
    batches = []

    if n > 0:
        current_jobs = [int(sorted_indices[0])]
        current_size = float(sorted_job_size[0])

        for k in range(1, n):
            current_job_index = int(sorted_indices[k])
            current_job_size = float(sorted_job_size[k])

            # 相邻工件 size 完全相同 -> 加入当前批次
            if current_job_size == current_size:
                current_jobs.append(current_job_index)

            # 相邻工件 size 不同 -> 关闭当前批次，建立新批次
            else:
                batch_id = len(batches) + 1
                job_count = len(current_jobs)
                total_size = current_size * job_count
                processing_time = current_size * (total_size + S) / S

                batches.append({
                    "batch_id": batch_id,
                    "size": current_size,
                    "jobs": current_jobs,
                    "job_count": job_count,
                    "total_size": total_size,
                    "processing_time": processing_time,
                })

                current_jobs = [current_job_index]
                current_size = current_job_size

        # 加入最后一个批次
        batch_id = len(batches) + 1
        job_count = len(current_jobs)
        total_size = current_size * job_count
        processing_time = current_size * (total_size + S) / S

        batches.append({
            "batch_id": batch_id,
            "size": current_size,
            "jobs": current_jobs,
            "job_count": job_count,
            "total_size": total_size,
            "processing_time": processing_time,
        })

    # ==========================================================
    # 3. 计算所有批次加工时间之和
    # ==========================================================
    total_processing_time = sum(
        batch["processing_time"] for batch in batches
    )

    # ==========================================================
    # 4. 按批次加工时间非增排序（LPT）
    # ==========================================================
    lpt_batches = sorted(
        batches,
        key=lambda batch: (-batch["processing_time"], batch["batch_id"])
    )

    # ==========================================================
    # 5. LPT：依次分配给当前负载最小的机器
    # ==========================================================
    machine_load = np.zeros(machine_num, dtype=float)
    machine_batches = [[] for _ in range(machine_num)]
    schedule = []

    for lpt_order, batch in enumerate(lpt_batches, start=1):
        # 当前负载最小的机器；负载相同时选编号较小的机器
        machine = int(np.argmin(machine_load))

        start_time = machine_load[machine]
        completion_time = start_time + batch["processing_time"]

        machine_batches[machine].append(batch["batch_id"])
        machine_load[machine] = completion_time

        schedule.append({
            "lpt_order": lpt_order,
            "batch_id": batch["batch_id"],
            "machine": machine,
            "start_time": start_time,
            "completion_time": completion_time,
            "processing_time": batch["processing_time"],
        })

    Cmax = float(np.max(machine_load))

    return (
        sorted_indices,
        sorted_job_size,
        batches,
        lpt_batches,
        total_processing_time,
        machine_batches,
        machine_load,
        schedule,
        Cmax,
    )


if __name__ == "__main__":
    machine_num = 2
    S = 30.0

    for n in (100, 120, 140, 160, 180, 200):
        print("m=", machine_num, ",n=", n)
        results = []
        total_start_time = time.perf_counter()

        for seed in range(101, 151):
            job_size = generate_jobs(n=n, seed=seed, s=S)

            start_time = time.perf_counter()
            Cmax_DP = dp_single_machine_value(job_size, S)
            (
                sorted_indices,
                sorted_job_size,
                batches,
                lpt_batches,
                total_processing_time,
                machine_batches,
                machine_load,
                schedule,
                Cmax,
            ) = same_size_batch_lpt(
                job_size=job_size,
                n=n,
                S=S,
                machine_num=machine_num,
            )
            cpu_time = time.perf_counter() - start_time

            lower_bound = Cmax_DP / machine_num
            gap = (Cmax - lower_bound) / lower_bound
            gap_percent = gap * 100
            results.append((Cmax, cpu_time, gap_percent, lower_bound))

            print(f"{Cmax:.3f}/{gap_percent:.4f}%/{lower_bound:.3f}")

        mean_cmax, mean_cpu, mean_gap_percent, mean_lower_bound = np.mean(
            results, axis=0
        )
        total_time = time.perf_counter() - total_start_time
        print("\nAverage over 50 instances:")
        print(
            f"{mean_cmax:.3f}/"
            f"{mean_gap_percent:.4f}%/{mean_lower_bound:.3f}"
        )
        print(f"Average running time: {mean_cpu:.6f} s")
        print(f"Total running time: {total_time:.6f} s")
