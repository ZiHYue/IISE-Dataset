from pathlib import Path

from openpyxl import Workbook, load_workbook


# 原始 Excel 文件路径
INPUT_FILE = Path(r"D:\桌面\新建XLSX 工作表 (2).xlsx")

# 输出文件路径：不会覆盖原始 Excel
OUTPUT_FILE = INPUT_FILE.with_name(
    f"{INPUT_FILE.stem}_分列{INPUT_FILE.suffix}"
)


def split_value(value):
    """把一个单元格按照 / 拆分，空单元格返回空列表。"""
    if value is None:
        return []
    return [part.strip() for part in str(value).split("/")]


def split_excel_columns(input_file, output_file):
    """将 Excel 每个工作表中的每一列按照 / 拆分成相邻的新列。"""
    source_wb = load_workbook(input_file, data_only=False)

    result_wb = Workbook()
    result_wb.remove(result_wb.active)

    for source_ws in source_wb.worksheets:
        result_ws = result_wb.create_sheet(source_ws.title)
        output_column = 1

        for source_column in range(1, source_ws.max_column + 1):
            # 计算当前原始列最多包含几组数据。
            # 例如 a/b 展开为两列，a/b/c 展开为三列。
            split_column_count = 1
            for row in range(1, source_ws.max_row + 1):
                parts = split_value(
                    source_ws.cell(row=row, column=source_column).value
                )
                split_column_count = max(split_column_count, len(parts))

            # 将当前原始列的所有单元格写入拆分后的相邻列。
            for row in range(1, source_ws.max_row + 1):
                parts = split_value(
                    source_ws.cell(row=row, column=source_column).value
                )

                for part_number, part in enumerate(parts):
                    result_ws.cell(
                        row=row,
                        column=output_column + part_number,
                        value=part,
                    )

            output_column += split_column_count

        # 设置拆分后各列的显示宽度。
        for column_cells in result_ws.columns:
            column_letter = column_cells[0].column_letter
            result_ws.column_dimensions[column_letter].width = 15

    result_wb.save(output_file)


if __name__ == "__main__":
    if not INPUT_FILE.exists():
        raise FileNotFoundError(f"找不到原始 Excel：{INPUT_FILE}")

    split_excel_columns(INPUT_FILE, OUTPUT_FILE)
    print(f"处理完成，结果已保存到：{OUTPUT_FILE}")
