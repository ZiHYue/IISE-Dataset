#!/usr/bin/env python
# coding=utf-8

import numpy as np
import time


def DP_C_batch(job_size, n, S):
    f = np.zeros(n + 1)
    sigma = np.zeros(n + 1, dtype=int)
    B = []

    # 边界条件
    f[n] = 0
    sigma[n] = n

    # 累积和
    cumulative_sum = np.zeros(n + 1)
    cumulative_sum[1:] = np.cumsum(job_size)

    # 反向DP
    for k in range(n - 1, -1, -1):
        si = k + 1
        fi = sigma[k + 1]

        if si > fi:
            f[k] = 0
            sigma[k] = si
            continue

        # 预计算 max_sj（从 si 到每个可能的 current_i 的最大值）
        max_sj_values = np.maximum.accumulate(job_size[si - 1:fi])

        fit_values = np.zeros(fi - si + 1)
        for i in range(fi - si + 1):
            current_i = si + i
            max_sj = max_sj_values[i]
            sum_si = cumulative_sum[current_i] - cumulative_sum[si - 1]
            fit_values[i] = max_sj * (1 + sum_si / S) + f[current_i]

        min_idx = np.argmin(fit_values)
        f[k] = fit_values[min_idx]
        sigma[k] = si + min_idx

    # 构建批次 B（用作业下标区间表示）
    j = 0
    while j < n:
        bs = sigma[j]
        B.append(np.arange(j, bs).tolist())
        j = bs

    # 计算每个批次加工时间 p[b]
    bn = len(B)
    p = np.zeros(bn)
    for b in range(bn):
        p[b] = max(job_size[B[b]]) * (1 + sum(job_size[B[b]]) / S)

    # 单机情形下，DP目标对应的总时间（这里你原代码叫 Cmax，但它是 sum p）
    Cmax_single = float(np.sum(p))
    return sigma, B, p, Cmax_single


def lpt_assign_batches(B, p, m):
    """
    按 LPT 规则将批次分配到 m 台机器：
    1) 批次按加工时间 p 非递增排序
    2) 依次分配到当前负载最小的机器
    返回：Cmax_multi, loads, assignment
      - loads[i]: 第 i 台机器总负载
      - assignment[i]: [(batch_id, p_time, jobs_in_batch), ...]
    """
    bn = len(B)
    order = sorted(range(bn), key=lambda b: p[b], reverse=True)

    loads = [0.0] * m
    assignment = [[] for _ in range(m)]

    for b in order:
        i = min(range(m), key=lambda t: loads[t])  # 当前负载最小
        loads[i] += float(p[b])
        assignment[i].append((b, float(p[b]), B[b]))

    Cmax_multi = max(loads) if loads else 0.0
    return Cmax_multi, loads, assignment

if __name__ == "__main__":
    n = 200
    S = 10
    m = 2

    total_start_time = time.time()

    # 保存全部算例的结果，用于计算最终平均值
    cmax_values = []
    gap_values = []
    lb_values = []
    cpu_time_values = []

    for seed in range(101, 151):
        np.random.seed(seed)

        job_size = np.random.uniform(low=1e-10, high=10.0, size=n)
        job_size = np.round(job_size, 3).astype(np.float32)
        job_size = np.sort(job_size)

        instance_start_time = time.time()

        sigma, B, p, Cmax_single = DP_C_batch(job_size, n, S)
        LB = Cmax_single / m

        Cmax_multi, loads, assignment = lpt_assign_batches(B, p, m)
        gap = (Cmax_multi - LB) / LB

        instance_cpu_time = time.time() - instance_start_time

        cmax_values.append(Cmax_multi)
        gap_values.append(gap)
        lb_values.append(LB)
        cpu_time_values.append(instance_cpu_time)

        print(f"{Cmax_multi :.3f}/{gap * 100:.4f}%/{LB:.3f}")

    total_end_time = time.time()

    # 输出全部50组算例的平均结果
    average_cmax = float(np.mean(cmax_values))
    average_gap = float(np.mean(gap_values))
    average_lb = float(np.mean(lb_values))
    average_cpu_time = float(np.mean(cpu_time_values))

    print("\nAverage over 50 instances:")
    print(
        f"{average_cmax:.3f}/"
        f"{average_gap * 100:.4f}%/{average_lb:.3f}"
    )
    print(f"总运行时间: {total_end_time - total_start_time:.6f} 秒")
