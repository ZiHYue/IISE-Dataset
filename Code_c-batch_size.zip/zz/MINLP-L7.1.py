#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""112,000件周工作量的单机 MINLP-L（同尺寸工件不可拆分）。"""

from __future__ import annotations

import time

import gurobipy as gp
from gurobipy import GRB


S = 30.0
TIME_LIMIT = 3600.0
MIP_GAP = 1e-4

# 与DP周实验完全相同的数据。
# 若论文日案例已有固定的10个小批量尺寸，只替换前10行的size即可。
TYPE_DATA = [
    (6.2, 700, "small"),
    (8.4, 700, "small"),
    (10.6, 700, "small"),
    (12.8, 700, "small"),
    (15.1, 700, "small"),
    (17.3, 700, "small"),
    (20.0, 700, "small"),
    (23.4, 700, "small"),
    (26.7, 700, "small"),
    (29.2, 700, "small"),
    (5.0, 21000, "large"),
    (7.0, 21000, "large"),
    (9.0, 21000, "large"),
    (11.0, 21000, "large"),
    (13.0, 21000, "large"),
]


def validate_data(type_data):
    if not type_data:
        raise ValueError("TYPE_DATA不能为空")
    if any(size <= 0 or size > S for size, _, _ in type_data):
        raise ValueError("所有工件尺寸必须位于(0,S]内")
    if any(count <= 0 for _, count, _ in type_data):
        raise ValueError("所有工件数量必须大于0")
    total_jobs = sum(count for _, count, _ in type_data)
    if total_jobs != 112000:
        raise ValueError(f"周工件总数应为112000，当前为{total_jobs}")


def build_and_solve(type_data):
    """
    类型聚合MINLP：
      x[t,k] = 1 表示尺寸类型t放入批次k；
      max_size[k]为批内最大尺寸；
      total_size[k]为批内所有工件尺寸之和；
      p[k] = max_size[k] * (1 + total_size[k]/S)。

    每个类型作为整体分配，因此同尺寸的全部工件必定属于同一批次。
    """
    validate_data(type_data)
    ordered = sorted(type_data, key=lambda row: row[0])
    sizes = [float(row[0]) for row in ordered]
    counts = [int(row[1]) for row in ordered]
    categories = [str(row[2]) for row in ordered]

    type_count = len(ordered)
    batch_count = type_count
    T = range(type_count)
    K = range(batch_count)

    model = gp.Model("MINLP_L_weekly_single_machine")

    x = model.addVars(T, K, vtype=GRB.BINARY, name="x")
    used = model.addVars(K, vtype=GRB.BINARY, name="used")
    selected_size = model.addVars(
        T, K, lb=0.0, ub=max(sizes), vtype=GRB.CONTINUOUS,
        name="selected_size",
    )
    max_size = model.addVars(
        K, lb=0.0, ub=max(sizes), vtype=GRB.CONTINUOUS,
        name="max_size",
    )
    total_size = model.addVars(
        K, lb=0.0, vtype=GRB.CONTINUOUS, name="total_size"
    )
    p = model.addVars(K, lb=0.0, vtype=GRB.CONTINUOUS, name="p")
    cmax = model.addVar(lb=0.0, vtype=GRB.CONTINUOUS, name="Cmax")

    # 每种尺寸的全部工件恰好分配到一个批次。
    model.addConstrs(
        (gp.quicksum(x[t, k] for k in K) == 1 for t in T),
        name="assign_type_once",
    )

    # 批次启用关系。
    model.addConstrs(
        (x[t, k] <= used[k] for t in T for k in K),
        name="use_batch_if_assigned",
    )
    model.addConstrs(
        (gp.quicksum(x[t, k] for t in T) >= used[k] for k in K),
        name="used_batch_nonempty",
    )

    # 消除等价批次编号产生的对称性。
    model.addConstrs(
        (used[k] >= used[k + 1] for k in range(batch_count - 1)),
        name="used_order",
    )

    for k in K:
        for t in T:
            model.addConstr(
                selected_size[t, k] == sizes[t] * x[t, k],
                name=f"selected_size_def_{t}_{k}",
            )

        model.addGenConstrMax(
            max_size[k],
            [selected_size[t, k] for t in T],
            constant=0.0,
            name=f"max_size_def_{k}",
        )
        model.addConstr(
            total_size[k]
            == gp.quicksum(counts[t] * sizes[t] * x[t, k] for t in T),
            name=f"total_size_def_{k}",
        )

        # 非凸双线性加工时间等式。
        model.addQConstr(
            p[k] == max_size[k] * (1.0 + total_size[k] / S),
            name=f"processing_time_def_{k}",
        )

    # 单机环境：Cmax等于全部非空批次加工时间之和。
    model.addConstr(cmax == gp.quicksum(p[k] for k in K), name="cmax_def")
    model.setObjective(cmax, GRB.MINIMIZE)

    model.Params.NonConvex = 2
    model.Params.OutputFlag = 1
    model.Params.Heuristics = 0.8
    model.Params.TimeLimit = TIME_LIMIT
    model.Params.MIPGap = MIP_GAP
    model.Params.Presolve = 2
    model.Params.Cuts = 2
    model.Params.MIPFocus = 1

    start = time.perf_counter()
    model.optimize()
    elapsed = time.perf_counter() - start

    result = {
        "model": model,
        "elapsed": elapsed,
        "ordered": ordered,
        "sizes": sizes,
        "counts": counts,
        "categories": categories,
        "x": x,
        "used": used,
        "max_size": max_size,
        "total_size": total_size,
        "p": p,
        "cmax": cmax,
        "T": T,
        "K": K,
    }
    return result


def print_result(result):
    model = result["model"]
    print("\n=== MINLP-L result ===")
    print(f"Status = {model.Status}")
    print(f"Runtime measured by Python = {result['elapsed']:.6f} seconds")
    print(f"Gurobi Runtime = {model.Runtime:.6f} seconds")

    if model.SolCount == 0:
        print("在时间限制内没有找到可行解。")
        return

    print(f"Cmax = {result['cmax'].X:.6f} seconds")
    print(f"Cmax = {result['cmax'].X / 3600.0:.6f} hours")
    print(f"Best bound = {model.ObjBound:.6f}")
    print(f"MIP gap = {model.MIPGap * 100:.6f}%")

    nonempty = []
    for k in result["K"]:
        if result["used"][k].X > 0.5:
            members = [
                t for t in result["T"]
                if result["x"][t, k].X > 0.5
            ]
            nonempty.append((k, members))

    print(f"Batch count = {len(nonempty)}")
    for sequence, (k, members) in enumerate(nonempty, start=1):
        member_text = [
            (
                result["sizes"][t],
                result["counts"][t],
                result["categories"][t],
            )
            for t in members
        ]
        print(
            f"B{sequence:02d}: types={member_text}, "
            f"max_size={result['max_size'][k].X:.1f}, "
            f"total_size={result['total_size'][k].X:.1f}, "
            f"p={result['p'][k].X:.6f}"
        )


def main():
    result = build_and_solve(TYPE_DATA)
    print_result(result)


if __name__ == "__main__":
    main()
