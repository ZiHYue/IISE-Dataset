#!/usr/bin/env python
# coding=utf-8

import numpy as np
import time


def same_size_batch_lpt(job_size, n, S, machine_num):
    """
    按 size 非减排序 + 相邻相同 size 组批 + LPT 多机调度

    规则：
    1. 保留原有工件 size 的随机生成方式；
    2. 所有工件按照 size 非减顺序排序；
    3. 从前到后依次比较相邻工件：
       - 若相邻工件 size 相同，则组成同一个批次；
       - 若 size 不同，则结束当前批次并开启新批次；
    4. 每个批次加工时间：
           p(B) = size * (total_size + S) / S
       其中 total_size 为该批次内所有工件 size 之和；
    5. 将批次按照加工时间 p(B) 非增排序；
    6. 按照 LPT 规则依次分配到当前负载最小的机器；
    7. Cmax = 最大机器负载。
    """

    if n != len(job_size):
        raise ValueError("n 与 job_size 的长度不一致！")
    if S <= 0:
        raise ValueError("S 必须大于 0！")
    if machine_num <= 0:
        raise ValueError("machine_num 必须大于 0！")

    # ==========================================================
    # 1. 将所有工件按照 size 非减排序
    # ==========================================================
    # 使用 stable 排序：size 相同时保持原工件编号的先后顺序
    sorted_indices = np.argsort(job_size, kind="stable")
    sorted_job_size = job_size[sorted_indices]

    # ==========================================================
    # 2. 比较排序后相邻工件的 size，连续相同 size 组成一个批次
    # ==========================================================
    batches = []

    if n > 0:
        current_jobs = [int(sorted_indices[0])]
        current_size = float(sorted_job_size[0])

        for k in range(1, n):
            current_job_index = int(sorted_indices[k])
            current_job_size = float(sorted_job_size[k])

            # 相邻工件 size 完全相同 -> 加入当前批次
            if current_job_size == current_size:
                current_jobs.append(current_job_index)

            # 相邻工件 size 不同 -> 关闭当前批次，建立新批次
            else:
                batch_id = len(batches) + 1
                job_count = len(current_jobs)
                total_size = current_size * job_count
                processing_time = current_size * (total_size + S) / S

                batches.append({
                    "batch_id": batch_id,
                    "size": current_size,
                    "jobs": current_jobs,
                    "job_count": job_count,
                    "total_size": total_size,
                    "processing_time": processing_time,
                })

                current_jobs = [current_job_index]
                current_size = current_job_size

        # 加入最后一个批次
        batch_id = len(batches) + 1
        job_count = len(current_jobs)
        total_size = current_size * job_count
        processing_time = current_size * (total_size + S) / S

        batches.append({
            "batch_id": batch_id,
            "size": current_size,
            "jobs": current_jobs,
            "job_count": job_count,
            "total_size": total_size,
            "processing_time": processing_time,
        })

    # ==========================================================
    # 3. 计算所有批次加工时间之和
    # ==========================================================
    total_processing_time = sum(
        batch["processing_time"] for batch in batches
    )

    # ==========================================================
    # 4. 按批次加工时间非增排序（LPT）
    # ==========================================================
    lpt_batches = sorted(
        batches,
        key=lambda batch: (-batch["processing_time"], batch["batch_id"])
    )

    # ==========================================================
    # 5. LPT：依次分配给当前负载最小的机器
    # ==========================================================
    machine_load = np.zeros(machine_num, dtype=float)
    machine_batches = [[] for _ in range(machine_num)]
    schedule = []

    for lpt_order, batch in enumerate(lpt_batches, start=1):
        # 当前负载最小的机器；负载相同时选编号较小的机器
        machine = int(np.argmin(machine_load))

        start_time = machine_load[machine]
        completion_time = start_time + batch["processing_time"]

        machine_batches[machine].append(batch["batch_id"])
        machine_load[machine] = completion_time

        schedule.append({
            "lpt_order": lpt_order,
            "batch_id": batch["batch_id"],
            "machine": machine,
            "start_time": start_time,
            "completion_time": completion_time,
            "processing_time": batch["processing_time"],
        })

    Cmax = float(np.max(machine_load))

    return (
        sorted_indices,
        sorted_job_size,
        batches,
        lpt_batches,
        total_processing_time,
        machine_batches,
        machine_load,
        schedule,
        Cmax,
    )


if __name__ == "__main__":
    # ========================== 算例参数 ==========================
    n = 200
    S = 10.0
    machine_num = 2

    # ======================== 随机生成 size =======================
    # 完全保留原代码的工件生成方式
    np.random.seed(42)

    job_size = np.random.uniform(
        low=1e-10,
        high=10.0,
        size=n
    )
    job_size = np.round(job_size, 3).astype(np.float32)

    start_time = time.time()

    (
        sorted_indices,
        sorted_job_size,
        batches,
        lpt_batches,
        total_processing_time,
        machine_batches,
        machine_load,
        schedule,
        Cmax,
    ) = same_size_batch_lpt(
        job_size=job_size,
        n=n,
        S=S,
        machine_num=machine_num,
    )

    end_time = time.time()

    print("=" * 80)
    print("Sorted Same-Size Batching + LPT Scheduling")
    print("=" * 80)
    print(f"Job Number     : {n}")
    print(f"Machine Number : {machine_num}")
    print(f"S              : {S}")
    print(f"Running Time   : {end_time - start_time:.6f} s")

    # ==========================================================
    # 输出原始工件 size
    # ==========================================================
    print("\n" + "=" * 80)
    print("Original Job Sizes")
    print("=" * 80)
    for j in range(n):
        print(f"J{j + 1}: size = {job_size[j]:.3f}")

    # ==========================================================
    # 输出 size 非减排序后的工件
    # ==========================================================
    print("\n" + "=" * 80)
    print("Jobs Sorted by Nondecreasing Size")
    print("=" * 80)

    for order, idx in enumerate(sorted_indices, start=1):
        print(
            f"{order}: J{int(idx) + 1}, "
            f"size = {job_size[int(idx)]:.3f}"
        )

    # ==========================================================
    # 输出组批结果
    # ==========================================================
    print("\n" + "=" * 80)
    print("Batch Formation by Adjacent Equal Sizes")
    print("=" * 80)

    for batch in batches:
        jobs_text = [f"J{j + 1}" for j in batch["jobs"]]

        print(f"\nB{batch['batch_id']}:")
        print(f"  Jobs = {jobs_text}")
        print(f"  Common Size = {batch['size']:.3f}")
        print(f"  Number of Jobs = {batch['job_count']}")
        print(f"  Total Size = {batch['total_size']:.3f}")
        print(f"  Processing Time = {batch['processing_time']:.3f}")

    # ==========================================================
    # 输出所有批次加工时间
    # ==========================================================
    print("\n" + "=" * 80)
    print("Batch Processing Times")
    print("=" * 80)

    for batch in batches:
        print(
            f"B{batch['batch_id']}: "
            f"size={batch['size']:.3f}, "
            f"p={batch['processing_time']:.3f}"
        )

    print(
        f"\nTotal Batch Processing Time = "
        f"{total_processing_time:.3f}"
    )

    # ==========================================================
    # 输出 LPT 排序结果
    # ==========================================================
    print("\n" + "=" * 80)
    print("LPT Batch Order")
    print("=" * 80)

    for order, batch in enumerate(lpt_batches, start=1):
        print(
            f"{order}: B{batch['batch_id']}, "
            f"size={batch['size']:.3f}, "
            f"p={batch['processing_time']:.3f}"
        )

    # ==========================================================
    # 输出机器分配结果
    # ==========================================================
    print("\n" + "=" * 80)
    print("Machine Assignment")
    print("=" * 80)

    batch_map = {
        batch["batch_id"]: batch for batch in batches
    }

    for m in range(machine_num):
        print(f"\nMachine {m + 1}:")

        assigned = [
            item for item in schedule
            if item["machine"] == m
        ]

        if not assigned:
            print("  No Batch")
        else:
            for item in assigned:
                batch = batch_map[item["batch_id"]]
                jobs_text = [
                    f"J{j + 1}" for j in batch["jobs"]
                ]

                print(
                    f"  B{item['batch_id']}: "
                    f"Jobs={jobs_text}, "
                    f"p={item['processing_time']:.3f}, "
                    f"start={item['start_time']:.3f}, "
                    f"completion={item['completion_time']:.3f}"
                )

        print(
            f"  Machine Load = {machine_load[m]:.3f}"
        )

    print("\n" + "=" * 80)
    print(
        f"Total Batch Processing Time = "
        f"{total_processing_time:.3f}"
    )
    print(f"Cmax = {Cmax:.3f}")
    LB= total_processing_time/2
    gap = (Cmax - LB) / LB
    print(f"gap = {gap * 100:.4f}%")
    print(
        f"{Cmax:.3f}/{end_time - start_time:.3f}s/{gap * 100:.4f}%"
    )
    print("=" * 80)