#!/usr/bin/env python
# coding=utf-8

import numpy as np
import time


def DP_C_batch(job_size, n, S):
    f = np.zeros(n + 1)
    sigma = np.zeros(n + 1, dtype=int)
    B = []

    # 边界条件
    f[n] = 0
    sigma[n] = n

    # 累积和
    cumulative_sum = np.zeros(n + 1)
    cumulative_sum[1:] = np.cumsum(job_size)

    # 反向DP
    for k in range(n - 1, -1, -1):
        si = k + 1
        fi = sigma[k + 1]

        if si > fi:
            f[k] = 0
            sigma[k] = si
            continue

        # 预计算 max_sj（从 si 到每个可能的 current_i 的最大值）
        max_sj_values = np.maximum.accumulate(job_size[si - 1:fi])

        fit_values = np.zeros(fi - si + 1)
        for i in range(fi - si + 1):
            current_i = si + i
            max_sj = max_sj_values[i]
            sum_si = cumulative_sum[current_i] - cumulative_sum[si - 1]
            fit_values[i] = max_sj * (1 + sum_si / S) + f[current_i]

        min_idx = np.argmin(fit_values)
        f[k] = fit_values[min_idx]
        sigma[k] = si + min_idx

    # 构建批次 B（用作业下标区间表示）
    j = 0
    while j < n:
        bs = sigma[j]
        B.append(np.arange(j, bs).tolist())
        j = bs

    # 计算每个批次加工时间 p[b]
    bn = len(B)
    p = np.zeros(bn)
    for b in range(bn):
        p[b] = max(job_size[B[b]]) * (1 + sum(job_size[B[b]]) / S)

    # 单机情形下，DP目标对应的总时间（这里你原代码叫 Cmax，但它是 sum p）
    Cmax_single = float(np.sum(p))
    return sigma, B, p, Cmax_single


def lpt_assign_batches(B, p, m):
    """
    按 LPT 规则将批次分配到 m 台机器：
    1) 批次按加工时间 p 非递增排序
    2) 依次分配到当前负载最小的机器
    返回：Cmax_multi, loads, assignment
      - loads[i]: 第 i 台机器总负载
      - assignment[i]: [(batch_id, p_time, jobs_in_batch), ...]
    """
    bn = len(B)
    order = sorted(range(bn), key=lambda b: p[b], reverse=True)

    loads = [0.0] * m
    assignment = [[] for _ in range(m)]

    for b in order:
        i = min(range(m), key=lambda t: loads[t])  # 当前负载最小
        loads[i] += float(p[b])
        assignment[i].append((b, float(p[b]), B[b]))

    Cmax_multi = max(loads) if loads else 0.0
    return Cmax_multi, loads, assignment


if __name__ == "__main__":
    n = 10000
    np.random.seed(101)
    job_size = np.random.uniform(low=1e-10, high=10.0, size=n)
    job_size = np.round(job_size, 3).astype(np.float32)
    job_size = np.sort(job_size)
    S = 10
    m = 20

    start_time = time.time()
    sigma, B, p, Cmax_single = DP_C_batch(job_size, n, S)
    LB = Cmax_single / m


    time1 = time.time()
    print(f"DP-BLPT运行时间= {time1 - start_time:.6f} 秒")


    # 多机：用 LPT 分配 DP 得到的批次
    Cmax_multi, loads, assignment = lpt_assign_batches(B, p, m)
    end_time = time.time()
    gap = (Cmax_multi - LB) / LB

    print("Job Number:", n)
    print(f"总运行时间: {end_time - start_time:.6f} 秒")
    print(f"LPT分配: {end_time - time1:.6f} 秒")
    print("Batch count:", len(B))
    print("Single-machine sum(p):", Cmax_single)

    num_batch = 0
    print("\n=== LPT assignment on m machines ===")
    # for i in range(m):
    #     print(f"Machine {i+1}: load = {loads[i]:.6f}, batches = {len(assignment[i])}")
    #     # for (bid, pb, jobs) in assignment[i]:
    #     #     print(f"  - batch#{bid}: p={pb:.6f}, |B|={len(jobs)}, jobs_idx=[{jobs[0]}..{jobs[-1]}]")
    #     num_batch += len(assignment[i])

    print("批次个数： ",num_batch)

    print("\nCmax (multi-machine):", Cmax_multi)
    print(f"Cmax_multi = {Cmax_multi :.3f}")
    print(f"gap = {gap :.6f}")
    print(f"gap = {gap * 100:.4f}%")
    print(f"{Cmax_multi :.3f}/{gap * 100:.4f}%")
    # print(f"LB = {LB:.3f}")




    # #1. LS 多品种小批量
    # type_data = [
    #     (0.34, 301),
    #     (0.66, 431),
    #     (2.46, 476),
    #     (2.93, 373),
    #     (5.83, 435),
    #     (6.72, 485),
    #     (7.41, 366),
    #     (8.87, 380),
    #     (11.88, 395),
    #     (12.61, 343),
    #     (14.69, 470),
    #     (15.91, 300),
    #     (16.49, 350),
    #     (16.87, 497),
    #     (18.70, 458),
    #     (20.71, 396),
    #     (20.98, 399),
    #     (21.04, 454),
    #     (21.59, 482),
    #     (22.23, 474),
    #     (23.58, 352),
    #     (23.76, 328),
    #     (24.21, 354),
    #     (24.27, 309),
    #     (24.31, 328),
    #     (24.43, 484),
    #     (24.44, 441),
    #     (24.49, 391),
    #     (24.55, 482),
    #     (24.63, 361),
    #     (24.65, 433),
    #     (24.71, 317),
    #     (24.77, 370),
    #     (24.82, 339),
    #     (24.93, 304),
    #     (24.95, 315),
    #     (24.96, 335),
    #     (24.97, 435),
    #     (24.99, 373),
    #     (25.00, 346),
    # ]

    # # 2. LPT 小品种大批量
    # type_data = [
    #     (5, 2594),
    #     (10, 3952),
    #     (15, 2332),
    #     (20, 4319),
    #     (25, 2389),
    # ]

    # # 1) 展开成作业列表：每个Ni重复numi次
    # Ni_vals = np.array([x for x, c in type_data], dtype=np.float32)
    # numi_vals = np.array([c for x, c in type_data], dtype=np.int32)
    #
    # job_size = np.repeat(Ni_vals, numi_vals).astype(np.float32)
    #
    # job_size = np.sort(job_size)
    # n = len(job_size)
    # m = 4
    # S = 30
