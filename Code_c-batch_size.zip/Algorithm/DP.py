"""
#!/usr/bin/env python
# coding=utf-8
@Author:Gongjie Xu
@Email:gjxu0928@gmail.com
@FileName:DP_AI优化后.py
@DateTime:2025/6/19 15:22
@SoftWare:Pycharm
"""

import numpy as np
import time


def DP_C_batch(job_size, n, S):
    f = np.zeros(n + 1)
    sigma = np.zeros(n + 1, dtype=int)
    B = []

    # 初始化边界条件
    f[n] = 0        #边界条件：没有作业时处理时间为0
    sigma[n] = n    #边界条件：没有作业时结束位置为n

    # 预计算累积和数组以优化求和操作
    cumulative_sum = np.zeros(n + 1)
    cumulative_sum[1:] = np.cumsum(job_size)

    # 反向动态规划，从 k=n-1 到 k=0 反向计算
    for k in range(n - 1, -1, -1):
        si = k + 1
        fi = sigma[k + 1]

        # 处理边界情况
        if si > fi:
            f[k] = 0
            sigma[k] = si
            continue

        # 使用累积和数组快速计算区间和
        sum_range = cumulative_sum[fi] - cumulative_sum[si - 1]

        # 预计算每个可能区间的max_sj
        max_sj_values = np.maximum.accumulate(job_size[si - 1:fi])

        # 计算每个可能区间的fit值
        fit_values = np.zeros(fi - si + 1)
        for i in range(fi - si + 1):
            current_i = si + i
            max_sj = max_sj_values[i]
            sum_si = cumulative_sum[current_i] - cumulative_sum[si - 1]
            fit_values[i] = max_sj * (1 + sum_si / S) + f[current_i]

        # 找到最小值和对应的索引
        min_idx = np.argmin(fit_values)
        f[k] = fit_values[min_idx]
        sigma[k] = si + min_idx

    # 构建批次
    j = 0
    while j < n:
        bs = sigma[j]
        B.append(np.arange(j, bs).tolist())
        j = bs
    bn = len(B)
    p = np.zeros(bn)
    for b in range(bn):
        p[b] = max(job_size[B[b]]) * (1 + sum(job_size[B[b]])/S)

    Cmax = np.sum(p)


    return sigma, B, p, Cmax


# # 算例数据`
# n = 100
# # 设置随机种子以便结果可重现
# np.random.seed(42)
# # 直接生成(0, 10]之间的均匀分布，排除0
# job_size = np.random.uniform(low=1e-10, high=5.0, size=n)
# # job_size = np.random.randint(low=1, high=5.0, size=n)
# # 使用astype进行内存优化
# job_size = np.round(job_size, 2).astype(np.float32)
# job_size = np.sort(job_size)#从小到大SPT排序
# S = 5



# 算例数据
n = 100 # 工件数量
m = 1   # 机器数量
L = 1000  # 增大M值
S = 30.0  # 加工室长度，同时为工件尺寸的上界


J = range(n)
M = range(m)
K = range(n)  # 批次数量，这里设置的为1至n最大批次数量

# 设置随机种子以便结果可重现
np.random.seed(42)

# 先在 (0.0, 30.0] 内随机生成 n/5 种工件尺寸，并保留一位小数；
# 然后将每种工件复制四份并与原集合拼接，使每种尺寸恰好对应五个工件。
if n % 5 != 0:
    raise ValueError(
        "The number of jobs n must be divisible by 5 so that each job type "
        "appears exactly five times."
    )

num_job_types = n // 5
candidate_sizes = np.round(np.arange(0.1, S + 0.1, 0.1), 1)
if num_job_types > len(candidate_sizes):
    raise ValueError(
        f"At most {5 * len(candidate_sizes)} jobs are supported when distinct sizes "
        "are retained to one decimal place in (0.0, 30.0]."
    )

# 从 0.1, 0.2, ..., 30.0 中无放回抽取，确保 n/5 个工件种类互不相同。
job_type_sizes = np.random.choice(candidate_sizes, size=num_job_types, replace=False)

# 保留原始集合，并整体复制四份，拼接为包含 n 个工件的初始输入集合。
js = np.tile(job_type_sizes, 5)
js = js.astype(np.float32)
job_size = np.sort(js)
# 求解前首先输出本次实验的全部输入工件。
print("All jobs:", job_size)

L = np.max(js) * (1 + np.sum(job_size)/S)  # 增大M值


start_time = time.time()
sigma, B, p, Cmax = DP_C_batch(job_size, n, S)
end_time = time.time()
print("Job Number:", n)
print(f"运行时间: {(end_time - start_time):.4f} 秒")
print("Job Size:", job_size)
print("sigma:", sigma)
print("Batches:", B)
print("Batche Processing time:", p)
# print("Cmax:", Cmax)
print(f"Cmax: {Cmax:.3f} ")
