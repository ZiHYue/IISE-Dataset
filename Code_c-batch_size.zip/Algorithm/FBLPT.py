#!/usr/bin/env python
# coding=utf-8

import time
import numpy as np

EPS = 1e-9


def generate_jobs(n, seed=42, low=1e-10, high=10.0):
    """按照指定随机方式生成工件 size，并按 size 非增排序。"""
    if n <= 0:
        raise ValueError("n 必须为正整数。")

    np.random.seed(seed)
    original_job_size = np.random.uniform(low=low, high=high, size=n)
    original_job_size = np.round(original_job_size, 3).astype(np.float32)

    # stable 排序保证 size 相同时保持原始编号顺序
    sorted_indices = np.argsort(-original_job_size, kind="stable")
    sorted_jobs = [
        (int(index + 1), float(original_job_size[index]))
        for index in sorted_indices
    ]

    return original_job_size, sorted_jobs


def form_batches_by_capacity(sorted_jobs, S):
    """
    按 size 非增排序后的工件顺序依次组批。
    若加入下一个工件后导致批次 size 总和超过 S，
    则关闭当前批次并建立新批次。
    """
    if S <= 0:
        raise ValueError("S 必须大于 0。")

    for job_id, size in sorted_jobs:
        if size <= 0:
            raise ValueError(f"工件 J{job_id} 的 size 必须大于 0。")
        if size > S + EPS:
            raise ValueError(
                f"工件 J{job_id} 的 size={size:.3f} 大于批容量 S={S:.3f}，"
                "无法组成可行批次。"
            )

    raw_batches = []
    current_batch = []
    current_sum = 0.0

    for job_id, size in sorted_jobs:
        if current_batch and current_sum + size > S + EPS:
            raw_batches.append(current_batch)
            current_batch = []
            current_sum = 0.0

        current_batch.append((job_id, size))
        current_sum += size

    if current_batch:
        raw_batches.append(current_batch)

    batches = []
    for batch_id, jobs in enumerate(raw_batches, start=1):
        batch_sum = sum(size for _, size in jobs)
        max_size = max(size for _, size in jobs)
        processing_time = max_size * (batch_sum + S) / S

        batches.append(
            {
                "original_batch_id": batch_id,
                "jobs": jobs,
                "sum_size": batch_sum,
                "max_size": max_size,
                "processing_time": processing_time,
            }
        )

    return batches


def assign_batches_lpt(batches, machine_num):
    """
    将批次按加工时间非增排序，再按照 LPT 规则依次分配给
    当前负载最小的机器。
    """
    if machine_num <= 0:
        raise ValueError("machine_num 必须为正整数。")

    sorted_batches = sorted(
        batches,
        key=lambda batch: (
            -batch["processing_time"],
            batch["original_batch_id"],
        ),
    )

    machines = [
        {
            "machine_id": machine_id,
            "load": 0.0,
            "batches": [],
        }
        for machine_id in range(1, machine_num + 1)
    ]

    for lpt_order, batch in enumerate(sorted_batches, start=1):
        selected_machine = min(
            machines,
            key=lambda machine: (
                machine["load"],
                machine["machine_id"],
            ),
        )

        start_time = selected_machine["load"]
        completion_time = start_time + batch["processing_time"]

        selected_machine["batches"].append(
            {
                "lpt_order": lpt_order,
                "batch": batch,
                "start_time": start_time,
                "completion_time": completion_time,
            }
        )
        selected_machine["load"] = completion_time

    Cmax = max(machine["load"] for machine in machines)
    return sorted_batches, machines, Cmax


def solve_fblpt_lpt(job_size, S, machine_num):
    """执行完整的组批与 LPT 多机分配流程。"""
    job_size = np.asarray(job_size, dtype=np.float32)

    sorted_indices = np.argsort(-job_size, kind="stable")
    sorted_jobs = [
        (int(index + 1), float(job_size[index]))
        for index in sorted_indices
    ]

    batches = form_batches_by_capacity(sorted_jobs, S)
    sorted_batches, machines, Cmax = assign_batches_lpt(
        batches, machine_num
    )

    return sorted_jobs, batches, sorted_batches, machines, Cmax


def print_solution(
    original_job_size,
    sorted_jobs,
    batches,
    sorted_batches,
    machines,
    Cmax,
    S,
):
    """打印完整调度结果。"""
    print("=" * 80)
    print("随机生成的原始 Job Size:")
    print(original_job_size)

    print("\n按 size 非增排序后的工件:")
    print([
        (f"J{job_id}", round(size, 3))
        for job_id, size in sorted_jobs
    ])

    print("\n" + "=" * 80)
    print("第一阶段：按 size 非增顺序依次组批")
    print(f"批容量 S = {S}")
    print("-" * 80)

    for batch in batches:
        job_text = ", ".join(
            f"J{job_id}(size={size:.3f})"
            for job_id, size in batch["jobs"]
        )

        print(f"B{batch['original_batch_id']}: [{job_text}]")
        print(f"    size 和 = {batch['sum_size']:.3f} <= {S:.3f}")
        print(f"    maxsize = {batch['max_size']:.3f}")
        print(
            "    p(B) = maxsize * (size和 + S) / S "
            f"= {batch['processing_time']:.6f}"
        )

    total_batch_processing_time = sum(
        batch["processing_time"] for batch in batches
    )
    print("\n所有批次加工时间之和:")
    print(f"sum p(B) = {total_batch_processing_time:.6f}")

    LB = total_batch_processing_time/machine_num

    print("\n" + "=" * 80)
    print("第二阶段：批次按加工时间非增排序")
    print("-" * 80)

    for order, batch in enumerate(sorted_batches, start=1):
        print(
            f"LPT顺序 {order}: B{batch['original_batch_id']}, "
            f"p={batch['processing_time']:.6f}"
        )

    print("\n" + "=" * 80)
    print("第三阶段：按照 LPT 规则分配到当前负载最小的机器")
    print("-" * 80)

    for machine in machines:
        print(f"Machine {machine['machine_id']}:")

        if not machine["batches"]:
            print("    无批次")

        for scheduled in machine["batches"]:
            batch = scheduled["batch"]
            job_ids = [f"J{job_id}" for job_id, _ in batch["jobs"]]

            print(
                f"    B{batch['original_batch_id']} {job_ids}, "
                f"p={batch['processing_time']:.6f}, "
                f"start={scheduled['start_time']:.6f}, "
                f"completion={scheduled['completion_time']:.6f}"
            )

        print(f"    Machine Load = {machine['load']:.6f}")
    gap = (Cmax - LB) / LB

    print("\n" + "=" * 80)
    print(f"Cmax = {Cmax:.3f}")
    print(f"LB = {LB:.4f}")
    print(f"gap = {gap * 100:.4f}%")
    print("=" * 80)


if __name__ == "__main__":
    # ========================== 算例数据 ==========================
    n = 100
    S = 10.0
    machine_num = 2
    random_seed = 42

    start_time = time.time()

    # 与原代码相同的随机数据生成方式
    original_job_size, _ = generate_jobs(
        n=n,
        seed=random_seed,
        low=1e-10,
        high=10.0,
    )

    (
        sorted_jobs,
        batches,
        sorted_batches,
        machines,
        Cmax,
    ) = solve_fblpt_lpt(
        job_size=original_job_size,
        S=S,
        machine_num=machine_num,
    )

    end_time = time.time()

    print(f"Job Number: {n}")
    print(f"Machine Number: {machine_num}")
    print(f"运行时间: {end_time - start_time:.6f} 秒")


    print_solution(
        original_job_size=original_job_size,
        sorted_jobs=sorted_jobs,
        batches=batches,
        sorted_batches=sorted_batches,
        machines=machines,
        Cmax=Cmax,
        S=S,
    )
    print(f"运行时间: {end_time - start_time:.6f} 秒")