#!/usr/bin/env python
# coding=utf-8

import numpy as np
import time


def FBLS(job_size, n, S, machine_num):
    """
    FBLS (Full-Batch List Scheduling)

    步骤：
    1. 工件保持原始列表顺序，不进行排序；
    2. 按照工件顺序依次组批；
    3. 每个批次满足 sum(size) <= S；
    4. 批次加工时间：
           p(B) = max_size * (sum_size + S) / S
    5. 批次保持原生成顺序，不按加工时间排序；
    6. 依次将批次分配给当前负载最小的机器；
    7. 计算最终 Cmax。
    """

    # ==========================================================
    # 1. 检查输入
    # ==========================================================
    if n != len(job_size):
        raise ValueError("n 与 job_size 的长度不一致！")

    if S <= 0:
        raise ValueError("S 必须大于 0！")

    if machine_num <= 0:
        raise ValueError("机器数量必须大于 0！")

    # 如果单个工件 size > S，则无法形成可行批次
    for j in range(n):
        if job_size[j] > S:
            raise ValueError(
                f"Job {j + 1} 的 size = {job_size[j]} > S = {S}，"
                f"无法组成可行批次！"
            )

    # ==========================================================
    # 2. 按原始工件顺序依次组批
    # ==========================================================
    B = []              # 所有批次
    current_batch = []  # 当前批次
    current_sum = 0.0   # 当前批次 size 和

    for j in range(n):

        size_j = float(job_size[j])

        # ------------------------------------------------------
        # 如果当前批次为空，直接加入
        # ------------------------------------------------------
        if len(current_batch) == 0:

            current_batch.append(j)
            current_sum = size_j

        else:

            # --------------------------------------------------
            # 加入当前工件后仍满足容量限制
            # --------------------------------------------------
            if current_sum + size_j <= S:

                current_batch.append(j)
                current_sum += size_j

            # --------------------------------------------------
            # 加入后超过 S：
            # 关闭当前批次，并建立新批次
            # --------------------------------------------------
            else:

                B.append(current_batch)

                current_batch = [j]
                current_sum = size_j

    # 加入最后一个批次
    if len(current_batch) > 0:
        B.append(current_batch)

    # 批次数量
    batch_num = len(B)

    # ==========================================================
    # 3. 计算每个批次的加工时间
    # ==========================================================
    p = np.zeros(batch_num)

    batch_sum_size = np.zeros(batch_num)
    batch_max_size = np.zeros(batch_num)

    for b in range(batch_num):

        # 当前批次中的 size
        sizes = job_size[B[b]]

        # size 总和
        sum_size = np.sum(sizes)

        # 最大 size
        max_size = np.max(sizes)

        # 保存数据
        batch_sum_size[b] = sum_size
        batch_max_size[b] = max_size

        # ------------------------------------------------------
        # 批次加工时间
        #
        # p(B) = maxsize * (size和 + S) / S
        # ------------------------------------------------------
        p[b] = max_size * (sum_size + S) / S

    total_processing_time = np.sum(p)
    LB = total_processing_time / machine_num
    # ==========================================================
    # 4. FBLS：按照批次原始生成顺序进行机器分配
    #
    # 注意：
    # 这里不能对 p 进行非增排序！
    #
    # B1 -> B2 -> ... -> Bk
    # ==========================================================

    # 每台机器当前负载
    machine_load = np.zeros(machine_num)

    # 每台机器所分配的批次
    machine_batches = [[] for _ in range(machine_num)]

    # 每个批次分配到哪台机器
    batch_machine = np.zeros(batch_num, dtype=int)

    # 每个批次开始时间
    batch_start = np.zeros(batch_num)

    # 每个批次完成时间
    batch_completion = np.zeros(batch_num)

    # ----------------------------------------------------------
    # 按照 B1, B2, ..., Bk 的顺序依次调度
    # ----------------------------------------------------------
    for b in range(batch_num):

        # 找当前负载最小的机器
        machine = np.argmin(machine_load)

        # 开始时间 = 当前机器已有负载
        batch_start[b] = machine_load[machine]

        # 完成时间
        batch_completion[b] = (
            batch_start[b] + p[b]
        )

        # 记录机器
        batch_machine[b] = machine

        # 当前批次加入该机器
        machine_batches[machine].append(b)

        # 更新机器负载
        machine_load[machine] += p[b]

    # ==========================================================
    # 5. 计算最终 Cmax
    # ==========================================================
    Cmax = np.max(machine_load)
    gap = (Cmax - LB) / LB

    return (
        B,
        p,
        batch_sum_size,
        batch_max_size,
        machine_batches,
        machine_load,
        batch_machine,
        batch_start,
        batch_completion,
        Cmax,
        gap
    )


# ==============================================================
# 主程序
# ==============================================================

if __name__ == "__main__":

    # ==========================================================
    # 算例参数
    # ==========================================================

    # 工件数量
    n = 200

    # 批容量
    S = 10

    # 并行机器数量
    machine_num = 2

    # ==========================================================
    # 随机生成工件 size
    # ==========================================================

    # 设置随机种子，保证每次运行结果一致
    np.random.seed(42)

    # 生成 (0, 10] 范围内的随机 size
    job_size = np.random.uniform(
        low=1e-10,
        high=10.0,
        size=n
    )

    # 保留三位小数，并转为 float32
    job_size = np.round(
        job_size,
        3
    ).astype(np.float32)

    # ==========================================================
    # FBLS 不对 job_size 排序
    #
    # 工件保持随机生成时的原始顺序：
    #
    # J1 -> J2 -> J3 -> ... -> Jn
    # ==============================================================

    # ==========================================================
    # 开始求解
    # ==========================================================
    start_time = time.time()

    (
        B,
        p,
        batch_sum_size,
        batch_max_size,
        machine_batches,
        machine_load,
        batch_machine,
        batch_start,
        batch_completion,
        Cmax,
        gap
    ) = FBLS(
        job_size,
        n,
        S,
        machine_num
    )

    end_time = time.time()

    # ==========================================================
    # 输出基本信息
    # ==========================================================
    print("=" * 80)

    print("FBLS Scheduling")

    print("=" * 80)

    print("Job Number:", n)

    print("Machine Number:", machine_num)

    print("S:", S)

    print(
        f"运行时间: "
        f"{end_time - start_time:.6f} 秒"
    )

    # ==========================================================
    # 输出工件 size
    # ==========================================================
    print("\n原始 Job Size:")

    for j in range(n):

        print(
            f"J{j + 1}: "
            f"size = {job_size[j]:.3f}"
        )

    # ==========================================================
    # 输出组批结果
    # ==========================================================
    print("\n" + "=" * 80)

    print("FBLS 组批结果")

    print("=" * 80)

    for b in range(len(B)):

        # 工件编号
        jobs = [
            f"J{j + 1}"
            for j in B[b]
        ]

        # 工件 size
        sizes = [
            float(job_size[j])
            for j in B[b]
        ]

        print(
            f"\nBatch B{b + 1}:"
        )

        print(
            f"  Jobs = {jobs}"
        )

        print(
            f"  Sizes = "
            f"{[round(x, 3) for x in sizes]}"
        )

        print(
            f"  Sum Size = "
            f"{batch_sum_size[b]:.3f}"
        )

        print(
            f"  Max Size = "
            f"{batch_max_size[b]:.3f}"
        )

        print(
            f"  Processing Time = "
            f"{p[b]:.6f}"
        )

    # ==========================================================
    # 所有批次的加工时间
    # ==========================================================
    print("\n" + "=" * 80)

    print("Batch Processing Times")

    print("=" * 80)

    for b in range(len(B)):

        print(
            f"B{b + 1}: "
            f"p = {p[b]:.6f}"
        )

    # ==========================================================
    # 输出机器分配结果
    # ==========================================================
    print("\n" + "=" * 80)

    print("FBLS Machine Assignment")

    print("=" * 80)

    for m in range(machine_num):

        print(
            f"\nMachine {m + 1}:"
        )

        if len(machine_batches[m]) == 0:

            print("  No Batch")

        else:

            for b in machine_batches[m]:

                jobs = [
                    f"J{j + 1}"
                    for j in B[b]
                ]

                print(
                    f"  B{b + 1}: "
                    f"Jobs={jobs}, "
                    f"p={p[b]:.6f}, "
                    f"start={batch_start[b]:.6f}, "
                    f"completion="
                    f"{batch_completion[b]:.6f}"
                )

        print(
            f"  Machine Load = "
            f"{machine_load[m]:.6f}"
        )

    # ==========================================================
    # 输出最终 Cmax
    # ==========================================================
    print("\n" + "=" * 80)

    print(
        f"Cmax = {Cmax:.3f}"
    )
    print(
        f"运行时间: "
        f"{end_time - start_time:.6f} 秒"
    )
    print(f"gap = {gap * 100:.4f}%")
    print(
        f"{Cmax:.3f}/{end_time - start_time:.3f}s/{gap * 100:.4f}%"
    )
    print("=" * 80)
